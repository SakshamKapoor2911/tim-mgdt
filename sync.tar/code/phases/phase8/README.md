# Phase 8: Large Model Scaling Validation

**Status**: 🟢 READY TO EXECUTE (code complete)  
**Target Models**: Mistral-7B, Llama-3-8B  
**Hardware**: 2x RTX 3090 (24GB VRAM each)  
**Execution**: Remote GPU setup required

---

## Objective

Validate that the 0.98x Layer 10 scaling breakthrough from GPT-2 (Phases 5-6) **transfers to larger, modern language models** (60x+ larger).

**Critical Question**:
> Does the optimal scaling principle hold across a 60x parameter gap (117M → 7B)?

---

## Architecture Motivation

| Aspect | GPT-2 | Mistral-7B | Llama-3-8B | Implication |
|--------|-------|-----------|-----------|-------------|
| Parameters | 117M | 7B (60x) | 8B (68x) | Scales with size |
| Layers | 12 | 32 | 32 | Different depth structure |
| Hidden Dim | 768 | 4096 | 4096 | Higher capacity |
| Attention Heads | 12 | 32 | 32 | More complex patterns |
| Max Seq Len | 1024 | 32768 | 8192 | Longer context |

### Key Insight

If the scaling principle is **architecture-agnostic**, then:
- ✓ Same scaling factor (0.98x) works across models
- ✓ Proportional layer selection (Layer 10 in 12-layer → Layer 16 in 32-layer)
- ✓ Foundation for production deployment on any model size

---

## Experimental Design

### Phase 8A: Mistral-7B Validation

1. **Load** Mistral-7B with 8-bit quantization (16GB VRAM)
2. **Baseline**: Compute PPL on 500 WikiText-2 samples
3. **Test Scales**: 0.90x, 0.92x, 0.95x, 0.98x, 1.00x on Layer 16
4. **Compare**: Against Phase 6 GPT-2 results
5. **Document**: Scaling pattern consistency

### Phase 8B: Llama-3-8B Validation

Same pipeline as 8A, using meta-llama/Meta-Llama-3-8B

---

## Quick Start

### Prerequisites

```bash
# Ensure requirements installed
cd implementation
pip install -r requirements.txt
pip install bitsandbytes accelerate  # For quantization
```

### Run Phase 8 Mistral Validation

```bash
# Single GPU execution (Recommended)
CUDA_VISIBLE_DEVICES=0 python code/phases/phase8/validation.py \
    --model mistral \
    --samples 500 \
    --precision int8 \
    --device cuda

# Output: experiments/phase8/mistral/<timestamp>/phase8_validation_*.{json,md}
```

### Run Phase 8 Llama Validation

```bash
# On second GPU (parallel execution possible)
CUDA_VISIBLE_DEVICES=1 python code/phases/phase8/validation.py \
    --model llama3 \
    --samples 500 \
    --precision int8 \
    --device cuda
```

---

## Expected Outcomes

### Scenario A: Perfect Transfer (Expected)
```
GPT-2 0.98x:     -0.11% PPL change  → Layer 10
Mistral 0.98x:   ~0.0%  PPL change  → Layer 16
Llama3 0.98x:    ~0.0%  PPL change  → Layer 16

Implication: ✓ Architecture-agnostic principle validated
```

### Scenario B: Proportional Shift
```
Mistral optimal: 0.96x or 0.97x instead of 0.98x
Reason: Scaled model may need slight adjustment
Action: Document the shift, update deployment guidelines
```

### Scenario C: Model-Specific Variance
```
Mistral:  0.98x → +0.5% PPL
Llama3:   0.98x → -0.2% PPL
Reason: Architecture differences may affect scaling sensitivity
Action: Create per-model lookup table
```

---

## Success Criteria

| Criterion | Threshold | Status |
|-----------|-----------|--------|
| Mistral baseline PPL | <100 | - |
| 0.98x PPL change | ±2% | - |
| Scaling layer consistent | Layer 16 | - |
| Execution time | <1hr per model | - |

---

## Code Organization

```
code/phases/phase8/
├── __init__.py              # Empty package marker
├── validation.py            # Phase8LargeModelValidator class
└── README.md               # This file

Execution:
python code/phases/phase8/validation.py --model mistral --samples 500
```

---

## Class: Phase8LargeModelValidator

### Key Methods

```python
validator = Phase8LargeModelValidator(
    model_name="mistral",           # mistral, llama3, llama2
    device="cuda",
    precision="int8"                # fp32, fp16, int8, int4
)

# Load data
eval_texts = validator.load_data(num_samples=500)

# Run all scale tests
results = validator.validate_scaling_factors(eval_texts)

# Generate report
report = validator.generate_validation_report(results, eval_texts)

# Save
validator.save_results(results, report, output_dir="...")
```

### Supported Models

| Model | model_name | Layers | Scaling Layer |
|-------|-----------|--------|---------------|
| Mistral-7B v0.1 | `mistral` | 32 | 16 |
| Llama-3-8B | `llama3` | 32 | 16 |
| Llama-2-7B | `llama2` | 32 | 16 |

---

## Output Files

For each run, Phase 8 generates:

1. **phase8_validation_results.json**
   ```json
   {
     "0.98": {
       "scale_factor": 0.98,
       "ppl": 52.34,
       "ppl_change_pct": -0.11,
       "tokens": 450000,
       "loss": 3.96
     },
     ...
   }
   ```

2. **phase8_validation_report.md**
   - Comparative analysis (GPT-2 vs Mistral)
   - Degradation pattern validation
   - Deployment recommendations
   - Next steps for Phase 9-10

---

## Timeline

| Phase | Task | Duration | Status |
|-------|------|----------|--------|
| 8 (Current) | Large model validation | 1-2 hours | 🟢 READY |
| 9 (Next) | Downstream tasks (GPT-2) | 2-3 hours | ⏳ Pending |
| 10 (Future) | Lottery ticket hypothesis | 2-4 hours | ⏳ Pending |
| 11 (Final) | Production deployment | Varies | ⏳ Pending |

---

## Troubleshooting

### Out of Memory (OOM)

**Solution 1**: Reduce samples
```bash
python code/phases/phase8/validation.py --samples 100 --precision int8
```

**Solution 2**: Use 4-bit quantization
```bash
python code/phases/phase8/validation.py --samples 500 --precision int4
```

**Solution 3**: Use cpu offload
```bash
# Modify code to use device_map="auto" in HookedTransformer
```

### Model Not Found

Ensure HF token configured:
```bash
huggingface-cli login
# Then enter token for gated models (Meta-Llama-3-8B requires access)
```

### Hook Issues

Some models may not support expected hook points. The validator has fallback logic to try alternative hook points. Check logs if hooks fail.

---

## Integration with Other Phases

- **Depends on**: Phase 5-6 (GPT-2 0.98x finding)
- **Validates**: Architecture-agnostic principle
- **Feeds to**: Phase 9 (downstream tasks), Phase 10 (lottery tickets)
- **Supports**: Phase 11 (production deployment)

---

## Related Documentation

- [Phase 6 Report](../../experiments/phase6/phase6_validation_report.md) - GPT-2 baseline
- [Phase 5 Guide](PHASE5_GUIDE.md) - Compression principles
- [Remote Setup Guide](../../REMOTE_SETUP_GUIDE.md) - GPU execution

---

## Next Phase: Phase 9

After Phase 8 completes successfully, proceed to Phase 9: Downstream Task Evaluation
- Sentiment analysis, QA, summarization
- Test if 0.98x scaling degrades real-world tasks
- Expected impact: <2% performance delta

---

**Author**: TIM-MGDT Project  
**Created**: 2026-04-24  
**Status**: Ready for execution
