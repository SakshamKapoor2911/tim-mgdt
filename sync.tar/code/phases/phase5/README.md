"""
Phase 5: Granular Compression Pipeline - README

This directory contains the implementation for Phase 5 of the TIM-MGDT project.
It transitions from diagnostic metrics (Phase 4) to active model compression using 
head-level granularity and the Lottery Ticket Hypothesis.

=== STRUCTURE ===

advanced_proxies/                    Phase 5 reusable components
├── head_jacobian.py               Head-level influence scores (∂logits/∂head)
├── circuit_analyzer.py            Stability scoring & ticket identification
├── pruning_engine.py              Masking-based compression engine
└── __init__.py

phase5/                             Master scripts
├── run_phase5_compression.py       Standalone Phase 5 pipeline (any model)
├── run_phase5_with_phase4_integration.py  Complete end-to-end (Phase 4 + 5)
└── __init__.py

run_benchmarks.py (UNCHANGED)       Phase 4 baseline - kept separate for CI

=== QUICK START ===

📋 Option 1: Standalone Phase 5 (Test Head Granularity)
   python phase5/run_phase5_compression.py --model gpt2 --head-samples 5
   → Generates: experiments/phase5_results.json
   → Shows: Head-level Jacobian, stability scores, pruning plan

🔗 Option 2: Full Integration (Phase 4 + Phase 5)
   python phase5/run_phase5_with_phase4_integration.py \
       --phase4-results experiments/sensitivity_results_500samples.json \
       --model gpt2 \
       --head-samples 5
   → Generates: experiments/phase5_integrated_results.json
   → Combines: Lottery tickets + your existing correlation results

=== COMPONENT DESCRIPTIONS ===

1. HeadJacobian (advanced_proxies/head_jacobian.py)
   ─────────────────────────────────────────────────
   Computes per-attention-head functional leverage:
   
   For each head: Jacobian_h = ||∂logits/∂head_output||_2
   
   Why: Layers aren't monoliths. A layer might have sensitivity=0.15,
        but maybe only 3 heads contribute 0.14 of that.
   
   Output: Dictionary mapping "layer_X_head_Y" → float score
   
   Key Methods:
   • compute_head_scores() - Main computation loop
   • aggregate_to_layer_level() - Compress back to layer scores
   • rank_heads_by_importance() - Sort heads within each layer

2. CircuitAnalyzer (advanced_proxies/circuit_analyzer.py)
   ───────────────────────────────────────────────────────
   Identifies "Winning Tickets" using stability scoring:
   
   Stability = (Jacobian / nAUDC) × (1 / ED)
   
   Why: Combines three perspectives:
   • Jacobian (numerator): Importance
   • nAUDC (denominator): Stability under noise
   • 1/ED (denominator): Specialization (not spread out)
   
   High Stability = Layer is doing focused, reliable, important work
   Low Stability = Layer is either unimportant, noisy, or redundant
   
   Output: Stability scores, lottery ticket classifications
   
   Key Methods:
   • find_winning_tickets() - Main scoring loop
   • identify_lottery_ticket_candidates() - Find (high J, low ED) patterns
   • compute_pruning_priority() - Sort layers for removal

3. PruningEngine (advanced_proxies/pruning_engine.py)
   ──────────────────────────────────────────────────
   Applies layer/head masks to demonstrate compression feasibility:
   
   Instead of destructively removing weights, we "hook" the model to
   zero-out specific layers/heads. This lets us measure the impact
   without permanently modifying the model.
   
   Why: Safe experimentation. We can:
   • Test if a layer is truly unimportant
   • Measure performance degradation quantitatively
   • Revert instantly (remove_all_masks())
   
   Output: Pruned model state, verification results
   
   Key Methods:
   • prune_bottom_k_layers() - Mask k least-important layers
   • prune_bottom_k_heads_per_layer() - Mask specific heads
   • remove_all_masks() - Restore baseline
   • apply_custom_mask_function() - Custom masking logic

=== RUNNING THE PIPELINE ===

Step 1: Baseline Phase 4 (if not already done)
─────────────────────────────────────────────
python run_benchmarks.py
→ Output: experiments/sensitivity_results_500samples.json
→ Metrics: ρ ≈ 0.86 (ensemble correlation with ground truth)

Step 2: Phase 5 Standalone (Optional - for debugging)
──────────────────────────────────────────────────
python phase5/run_phase5_compression.py --model gpt2 --head-samples 5
→ Output: experiments/phase5_results.json
→ Shows: Head-level diagnostic capability

Step 3: Phase 4 + Phase 5 Integration (Main Event)
──────────────────────────────────────────────────
python phase5/run_phase5_with_phase4_integration.py \
    --phase4-results experiments/sensitivity_results_500samples.json \
    --model gpt2 \
    --head-samples 5
→ Output: experiments/phase5_integrated_results.json
→ Shows: Full compression pipeline ready for implementation

Step 4: Model Scaling (Optional - Cloud)
───────────────────────────────────────
# Same scripts, different model:
python phase5/run_phase5_with_phase4_integration.py \
    --model mistralai/Mistral-7B-v0.1 \
    --head-samples 10

=== HARDWARE REQUIREMENTS ===

Local Testing (Phase 5 Head Jacobian):
• Model: gpt2 or Qwen/Qwen2.5-0.5B
• VRAM: 4-6 GB
• Runtime: ~2-5 minutes

Cloud Testing (Mistral-7B):
• Model: mistralai/Mistral-7B-v0.1
• VRAM: 16+ GB (with 8-bit)
• Runtime: ~10-20 minutes

=== INTERPRETING RESULTS ===

experiments/phase5_integrated_results.json contains:

{
  "phase4": {
    "model": "gpt2",
    "num_samples": 500,
    "correlations": { "Ensemble (ED+invJac+invnAUDC)": {"spearman_rho": 0.86, ...} }
  },
  "phase5": {
    "head_jacobian_scores": { "layer_0_head_0": 123.45, ... },
    "stability_scores": { "layer_0": 1.23e+5, ... },
    "lottery_ticket_candidates": {
      "layer_0": { "is_lottery_ticket": true, "jacobian": ..., "ed": ... },
      ...
    },
    "pruning_plan": {
      "pruned_layers": [1, 2, 3],
      "k_prune": 3,
      "pruning_percentage": 25.0
    }
  }
}

Key Interpretation:
• "pruned_layers": [1, 2, 3] = Remove these 3 layers
• Expected result: ~25% model size reduction with minimal accuracy loss
• If you remove 3 out of 12 layers and perplexity increases by <5%, your
  proxies are validated for production compression.

=== NEXT STEPS (Phase 5.1) ===

After validating the pruning plan, the next phase will:

1. Actually prune weights (not just mask)
2. Fine-tune the pruned model
3. Benchmark end-to-end performance
4. Deploy to edge devices

The scripts here are *diagnostic*. Once you confirm that removing layers
identified by your proxies doesn't significantly hurt performance, you
have the justification to deploy actual compression.

=== TROUBLESHOOTING ===

Q: "CUDA out of memory"
A: Reduce --head-samples or use a smaller model (qwen instead of gpt2)

Q: "Module 'hooks' not found"
A: Ensure transformer_lens is installed: pip install transformer-lens

Q: "Phase 4 results file not found"
A: Check the path with: ls experiments/sensitivity_results_*.json

Q: "Pruning doesn't reduce inference time"
A: Masking (this Phase 5) doesn't reduce compute. Full pruning (Phase 5.1)
   will actually remove weights and reduce FLOPs.

=== CITATION & THEORY ===

This pipeline is grounded in:
• Frankle & Carbin (2019): "The Lottery Ticket Hypothesis"
• Jvula et al. (in your references): TIM framework
• Zhang et al. (2023): Mechanistic interpretability for compression

See: implementation/references.bib

=== AUTHOR NOTES ===

Separation of Concerns:
• run_benchmarks.py (Phase 4) is UNTOUCHED
• Phase 5 is in its own folder structure (advanced_proxies/ + phase5/)
• This enables parallel experimentation without breaking the baseline

Clean Integration:
• Phase 5 imports Phase 4 tools (HookedModelWrapper, ablation)
• But doesn't modify them
• Both pipelines can run independently or together
"""

# This file is intentionally written as a long docstring for reference.
# To read it, use: python -c "import phase5_readme; print(phase5_readme.__doc__)"
