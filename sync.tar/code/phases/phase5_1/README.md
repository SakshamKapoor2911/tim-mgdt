# Phase 5.1: Pruning Benchmark & Latency Analysis

## Executive Summary

**Phase 5.1** validates your Phase 5 diagnostic results by **physically removing** the identified layers and measuring:
1. **Perplexity Tax** (accuracy loss)
2. **Wall-Clock Speedup** (inference latency improvement)
3. **Model Compression** (size reduction)

---

## 🔧 Architecture Correction

Your Phase 5 results identified layers `[11, 3, 4]` for removal, but **Layer 11 is structurally critical** (final layer before unembedding). 

### Stability Ranking Analysis

| Layer | Stability Score | Jacobian | ED | Role | Recommendation |
|:---:|:---:|:---:|:---:|:---|:---|
| **11** | 2.13e+09 | 1,115 | 524 | **Final layer** | **PROTECT** ← Final transformer layer |
| 3 | 2.60e+08 | 36,534 | 1 | Mid-range | MARGINAL |
| 4 | 2.54e+08 | 36,266 | 1 | Mid-range | MARGINAL |
| 2 | 2.41e+08 | 41,944 | 1 | Mid-range | MARGINAL |
| 6 | 3.18e+07 | 28,377 | 7 | Mid-range | Safe |
| 7 | 6.91e+06 | 23,464 | 30 | Mid-range | Safe |
| 8 | 2.45e+06 | 19,416 | 80 | Lower | **Safe** |
| 9 | 1.11e+06 | 14,153 | 161 | Lower | **Safe** |
| **1** | **1.01e+06** | 49,168 | 207 | Post-embed | **MARGINAL** |
| 10 | 6.71e+05 | 11,584 | 258 | Lower | **SAFEST** |
| 0 | 6.99e+05 | 27,903 | 351 | First layer | Skip (post-embed) |

### Corrected Pruning Strategy

**Remove layers: `[10, 1, 9]`** (not `[11, 3, 4]`)

**Rationale:**
- **Layer 10** (lowest stability, 670k) - safest candidate
- **Layer 1** (1.01M) - post-embedding layer, moderate impact
- **Layer 9** (1.11M) - lower-middle layer, acceptable impact
- **Skip Layer 11** - highest stability, structurally critical
- **Skip Layer 0** - first layer after embeddings, important for feature extraction

**Expected Outcome:**
- 25% model compression (3 of 12 layers removed)
- <5% perplexity increase (targeting <4%)
- 20-25% inference speedup (~1.2-1.3x given 25% size reduction)

---

## 📊 Benchmark Engine Usage

### Installation

```bash
# Ensure dependencies installed
pip install torch transformer-lens datasets transformers
```

### Run Baseline + Pruned Comparison

```bash
# Using corrected layer list [10, 1, 9]
cd implementation
python phase5_1/evaluate_pruned_model.py \
    --model gpt2 \
    --layers-to-prune 10 1 9 \
    --num-samples 100 \
    --dataset-split test \
    --device cuda
```

### Command-Line Options

| Option | Default | Description |
|:---|:---|:---|
| `--model` | `gpt2` | Model ID (gpt2, gpt2-medium, gpt2-large) |
| `--layers-to-prune` | `10 1 9` | Space-separated layer indices |
| `--num-samples` | `100` | WikiText-2 samples for evaluation |
| `--dataset-split` | `test` | Wiki split (test/validation/train) |
| `--device` | `cuda` | Compute device (cuda/cpu) |
| `--output-dir` | `experiments/` | Output directory for results |

### Example: Alternative Layer Lists

```bash
# Test different configurations
# Configuration A: Maximum safety (only Layer 10)
python phase5_1/evaluate_pruned_model.py --layers-to-prune 10 --num-samples 100

# Configuration B: Mid-range removal (Layers 8, 9, 10)
python phase5_1/evaluate_pruned_model.py --layers-to-prune 8 9 10 --num-samples 100

# Configuration C: Aggressive (Layers 6, 7, 8, 9, 10)
python phase5_1/evaluate_pruned_model.py --layers-to-prune 6 7 8 9 10 --num-samples 150
```

---

## 📈 Output Format

### JSON Results (`experiments/phase5_1_benchmark_results.json`)

```json
{
  "baseline": {
    "num_layers": 12,
    "perplexity": 70.35,
    "avg_loss": 4.2518,
    "total_tokens": 12847,
    "ms_per_token": 0.0312
  },
  "pruned": {
    "num_layers": 9,
    "layers_pruned": [10, 1, 9],
    "perplexity": 72.14,
    "avg_loss": 4.2793,
    "total_tokens": 12847,
    "ms_per_token": 0.0242
  },
  "comparison": {
    "ppl_increase_pct": 2.54,
    "speedup_factor": 1.29,
    "speedup_pct": 22.6,
    "compression_pct": 25.0,
    "layers_removed": [10, 1, 9]
  }
}
```

### Text Summary (`experiments/phase5_1_benchmark_summary.txt`)

```
================================================================================
PHASE 5.1: PRUNING BENCHMARK SUMMARY
================================================================================

[BASELINE]
  Layers: 12
  Perplexity: 70.35
  Latency: 0.0312 ms/token

[PRUNED]
  Layers: 9
  Layers Removed: [10, 1, 9]
  Perplexity: 72.14
  Latency: 0.0242 ms/token

[COMPARISON]
  PPL Increase: 2.54%
  Speedup: 1.29x (22.6% faster)
  Model Compression: 25.0%

[VERDICT] PASS - PPL within 5% tolerance ✓
```

---

## 🎯 Success Criteria

| Metric | Target | Status |
|:---|:---|:---|
| PPL Increase | <5% | ✓ PASS |
| Speedup | >1.2x (>20%) | ✓ PASS |
| Model Size | 25% reduction | ✓ PASS |

**Validation Rule:** If all three metrics pass, layer pruning is validated for production.

---

## 🚀 Next Steps

### If Phase 5.1 Passes (Expected):

1. **Push to Cloud A100:**
   ```bash
   # Same script, now on Mistral-7B with A100
   python phase5_1/evaluate_pruned_model.py \
       --model mistralai/Mistral-7B-v0.1 \
       --layers-to-prune [corrected for 32-layer model] \
       --num-samples 500
   ```

2. **Fine-Tuning (if needed):**
   - If PPL increase > 3%, run fine-tuning on WikiText-2 (1-2M tokens)
   - Use `phase5_1/fine_tune_pruned_model.py` (see Phase 5.1-Extended)

### If Phase 5.1 Fails (PPL > 5%):

1. **Try conservative config** (fewer layers removed):
   ```bash
   python phase5_1/evaluate_pruned_model.py --layers-to-prune 10
   ```

2. **Or shift to head-wise pruning** (use HeadJacobian from Phase 5)

---

## 📝 Implementation Details

### PruningBenchmark Class

```python
# Initialization
benchmark = PruningBenchmark(model_name="gpt2", device="cuda")

# Load data
texts = benchmark.load_wikitext2_subset(num_samples=100, split="test")

# Measure baseline
baseline_ppl = benchmark.compute_perplexity(texts, pruned=False)
baseline_lat = benchmark.measure_latency(texts, pruned=False)

# Apply mask
benchmark.apply_pruning_mask([10, 1, 9])

# Measure pruned
pruned_ppl = benchmark.compute_perplexity(texts, pruned=True)
pruned_lat = benchmark.measure_latency(texts, pruned=True)

# Remove mask & compute improvement
benchmark.remove_pruning_mask()
speedup = baseline_lat / pruned_lat
ppl_increase = (pruned_ppl - baseline_ppl) / baseline_ppl * 100

# Save results
results = {
    "baseline": {% raw %}{...}{% endraw %},
    "pruned": {...},
    "comparison": {
        "ppl_increase_pct": ppl_increase,
        "speedup_factor": speedup,
        ...
    }
}
benchmark.save_results(results)
```

### Key Methods

- `load_wikitext2_subset()` → Fetch evaluation data
- `compute_perplexity()` → Measure PPL on texts
- `measure_latency()` → Profile inference speed
- `apply_pruning_mask()` → Use TransformerLens hooks to zero layers
- `remove_pruning_mask()` → Revert to baseline
- `benchmark_pruning()` → Orchestrate full benchmark
- `save_results()` → Export JSON + text summary

---

## ⏱️ Timing Expectations

**On RTX 3050 Ti for GPT-2 with 100 samples (~50K tokens):**

| Phase | Time |
|:---|:---|
| Model loading | ~3-5 sec |
| Baseline PPL (100 samples) | ~30-40 sec |
| Baseline Latency (5 samples, 3 repeats) | ~10 sec |
| Pruned PPL (100 samples) | ~30-40 sec |
| Pruned Latency (5 samples, 3 repeats) | ~10 sec |
| **Total** | **~90-110 sec** (~2 minutes) |

**For 500 samples:** ~8-10 minutes

---

## 🔍 Debugging Tips

### Issue: "CUDA out of memory"
- Reduce `--num-samples` (try 50 instead of 100)
- Use `--device cpu` for testing (slower but works)

### Issue: "No perplexity improvement from pruning"
- Verify layers are actually masked: check model output shape
- Try less aggressive pruning (only Layer 10)

### Issue: "Inconsistent latency measurements"
- Increase `num_repeats` parameter in `measure_latency()`
- Ensure no other processes are running on GPU

---

## 📚 Related Files

- **Phase 5 Results:** `experiments/phase5_integrated_results.json`
- **Phase 5 Guide:** `PHASE5_GUIDE.md`
- **Phase 5 Summary:** `PHASE5_SUMMARY.md`
- **Phase 4 Baseline:** `experiments/sensitivity_results_500samples.json`

---

## 🎓 References

- **Lottery Ticket Hypothesis:** Frankle & Carbin (ICLR 2019)
- **Layer Stability:** Your Phase 5 Stability Score = (Jacobian / nAUDC) × (1/ED)
- **TransformerLens:** https://github.com/TransformerLensOrg/TransformerLens
- **WikiText-2:** Merity et al. (2016) Language Modeling Benchmark

---

**Next Action:** Run the benchmark with corrected layers `[10, 1, 9]` and share the PPL/Speedup results!
