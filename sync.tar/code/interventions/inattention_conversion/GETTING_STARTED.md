# Phase 7.1: InAttention Conversion - Quick Start Guide

## What Is Phase 7.1?

Phase 7.1 is the **first real model compression** test, moving from soft scaling validation (Phase 6) to architectural modifications.

**Goal**: Convert Layer 10's standard self-attention to **InAttention** (linear-scaling attention) and measure:
- ✓ PPL impact (target: <5% delta)
- ✓ Inference speedup (target: >1.5x)
- ✓ VRAM reduction (target: >30%)

---

## Why Layer 10?

Phase 6 proved that Layer 10 is **elastic** — it tolerates 0.98x scaling without damage. This elasticity is the prerequisite for architectural modifications like InAttention.

**What is InAttention?**
- Standard attention: Each token attends to ALL tokens (O(T²) memory)
- InAttention: Each token attends ONLY to the first token (O(T) memory)
- Result: Linear memory scaling instead of quadratic

---

## Project Structure

```
interventions/inattention_conversion/
├── README.md                          ← Design documentation
├── run_inattention_validation.py      ← Entry point (run this!)
├── code/
│   ├── inattention_layer.py          ← InAttention module implementation
│   ├── attention_hooks.py            ← TransformerLens hook integration
│   └── validate_single_layer.py       ← Core validation script
└── experiments/
    └── single_layer/
        └── results/
            ├── inattention_layer10_results.json    ← Raw metrics
            └── inattention_layer10_report.md       ← Analysis report
```

---

## Running Phase 7.1

### Option 1: Quick Run (Recommended)

```bash
cd interventions/inattention_conversion
python run_inattention_validation.py --num-samples 100 --device cuda
```

**Arguments**:
- `--num-samples`: Number of WikiText-2 samples (default: 500, use 100 for quick test)
- `--device`: "cuda" or "cpu" (default: cuda)
- `--model`: Model name (default: gpt2)

### Option 2: Direct Script Run

```bash
python interventions/inattention_conversion/code/validate_single_layer.py --num-samples 500
```

### Option 3: Python Environment

```python
from interventions.inattention_conversion.code.validate_single_layer import InAttentionValidator

validator = InAttentionValidator(model_name="gpt2", device="cuda")
validator.run_full_validation(num_samples=500)
```

---

## What The Script Does

1. **Loads Model**: GPT-2 via TransformerLens
2. **Baseline Test**: Measures PPL with standard attention
3. **InAttention Test**: Applies InAttention hook to Layer 10
4. **Progressive Scaling**: Tests InAttention with different scale factors
5. **Comparison**: Compares results with Phase 6 baseline
6. **Reports**: Saves JSON metrics and markdown analysis

**Expected Runtime**: ~5-10 minutes (for 500 samples)

---

## Understanding Output

### Console Output Example

```
[INFO] Loading gpt2 on cuda...
[OK] Model loaded: 12 layers, 768 hidden, 12 heads

================================================================================
PHASE 7.1: INATTENTION CONVERSION - LAYER 10 VALIDATION
================================================================================

--- BASELINE: Standard Attention ---
Baseline PPL: 51.4266
  Tokens: 36583
  Time: 45.23s

--- INATTENTION: Layer 10 ---
InAttention PPL: 52.1456
  Tokens: 36583
  Time: 32.15s

Results:
  PPL Delta: +0.7190 (+1.40%)
  Speedup: 1.41x
  Status: ✓ PASS (target: <5%)
```

### Result Files

**`inattention_layer10_results.json`**: Raw metrics
```json
{
  "metadata": {...},
  "validation": {
    "baseline": {
      "ppl": 51.4266,
      "tokens": 36583,
      "time_sec": 45.23
    },
    "inattention_layer10": {
      "ppl": 52.1456,
      "tokens": 36583,
      "time_sec": 32.15
    },
    "metrics": {
      "ppl_delta": 0.719,
      "ppl_delta_pct": 1.40,
      "speedup": 1.41,
      "pass_criteria": true
    }
  }
}
```

**`inattention_layer10_report.md`**: Human-readable analysis with Phase 6 comparison

---

## Success Criteria

| Criterion | Target | Pass/Fail |
|-----------|--------|-----------|
| **PPL Delta** | <5% | ✓ if < 5% |
| **Inference Speedup** | >1.5x | ✓ if > 1.5x |
| **VRAM Reduction** | >30% | ✓ if > 30% |
| **Reproducibility** | Consistent | ✓ if matches Phase 6 |

---

## Next Steps (After Phase 7.1)

### If PPL Delta < 5% ✓
→ **Progressive Layer Testing**: Test InAttention on layers 4-7 (mid-depth)

### If PPL Delta > 5% ⚠️
→ **Hybrid Recovery**: Combine InAttention + 0.98x scaling for better recovery

### Always
→ **VRAM Profiling**: Measure actual memory savings vs theoretical

---

## Common Issues & Fixes

### Issue: CUDA Out of Memory
**Solution**: Reduce `--num-samples` to 100 or use `--device cpu`

### Issue: ImportError on attention_hooks
**Solution**: Run from `interventions/inattention_conversion/code/` directory

### Issue: Slow on CPU
**Expected**: CPU inference is 10-20x slower; use GPU if available

---

## Code Architecture

### InAttention Layer (`inattention_layer.py`)
- **InAttentionHead**: Single head that attends only to position 0
- **InAttentionBlock**: Multi-head wrapper
- **InAttentionAnalyzer**: Memory savings calculator

### Attention Hooks (`attention_hooks.py`)
- **AttentionHookManager**: Manages hook registration/removal
- **HybridAttentionManager**: Multiple layers with mixed attention
- **MemoryProfiler**: Profiles memory usage

### Validation Script (`validate_single_layer.py`)
- **InAttentionValidator**: Main validation class
- **compute_perplexity_and_time()**: PPL + speed measurement
- **validate_inattention_layer10()**: Core test logic
- **generate_markdown_report()**: Report generation

---

## Technical Reference

**Paper**: InAttention - LINEAR CONTEXT SCALING FOR TRANSFORMERS  
**Framework**: TransformerLens + HuggingFace Transformers  
**Model**: GPT-2 (12 layers, 768 hidden dims, 12 heads)  
**Dataset**: WikiText-2 (test split)

---

## Tips for Best Results

1. **Start with 100 samples** for quick validation (~2 min)
2. **Use 500 samples** for final results (reproduced from Phase 6)
3. **Run multiple times** to check reproducibility
4. **Compare JSON outputs** across runs using `jq` or Python

---

## Questions?

- Check `DEBUG.md` for troubleshooting
- Review `interventions/inattention_conversion/README.md` for technical details
- See `experiments/single_layer/results/*.json` for raw metrics

**Next: Run the validation and move to Phase 7.2 (Progressive Layer Testing)**
