# InAttention Conversion: Linear Scaling of Long-Context Inference

**Status**: 📋 READY FOR IMPLEMENTATION  
**Priority**: 🔴 HIGH (Directly addresses compute scaling)  
**Target Model**: GPT-2 (validate), Mistral-7B (scale)  
**Expected Impact**: **70-85% VRAM reduction**, 4x inference speedup

---

## Objective

Convert dense self-attention in Layer 10 (or selectively in other layers) to **InAttention** — a linear-scaling alternative that reduces VRAM from O(T²) to O(T) where T is sequence length.

---

## Technical Summary

### Standard Self-Attention (Quadratic)
```
Attention(Q, K, V) = softmax(QK^T / √d)V
# For sequence length T: O(T²) memory, O(T²) computation
```

### InAttention (Linear)
```
# Each position's hidden state attends only to initial token states
# Collapses attention matrix into a vector (per-head)
# Eliminates KV-cache requirement
```

---

## The InAttention Paper

**Reference**: [InAttention: LINEAR CONTEXT SCALING FOR TRANSFORMERS](https://arxiv.org/abs/XXXX.XXXXX)

### Key Findings from Paper

| Finding | Impact | Relevance |
|---------|--------|-----------|
| 4096-token: 18GB → ~3.2GB VRAM | **82% reduction** | Extreme memory savings |
| 16k-32k tokens on 16GB GPU | Enables long context | Production-critical |
| Capability loss: small & stable | <2-3% accuracy | Acceptable tradeoff |
| Performance stable with model size | Scales well | Works on 7B+ models |
| Cheap finetuning extends context | Recoverable | High ROI potential |

---

## Phase 6 + InAttention Synergy

**Why Now?**

Phase 6 discovered that **Layer 10 is elastic** (0.98x scaling works). This elasticity is the prerequisite for InAttention conversion:

1. ✓ Layer 10 proved it can tolerate parameter modifications
2. ✓ Soft scaling showed no architectural damage
3. → **Ready to replace attention mechanism with InAttention**

---

## Implementation Strategy

### Stage 1: Validate on Single Layer (GPT-2)

1. **Identify Target Layer**: Layer 10 (proven elastic from Phase 6)
2. **Swap Attention Mechanism**: Replace dense self-attention with InAttention
3. **Measure Impact**:
   - VRAM reduction (should be 30-50% for single layer)
   - Performance (PPL impact)
   - Speed (inference latency reduction)

### Stage 2: Progressive Layer Conversion

Test which layers can be **safely** converted to InAttention:

| Layer | Criticality | Recommendation |
|-------|-------------|-----------------|
| 0-3 (Early) | High extractive signals | Keep dense |
| 4-7 (Mid) | Mixed | Convert (expected 80% success) |
| 8-10 (Late-mid) | High semantic | Selective (test individually) |
| 11 (Very Late) | High output quality | Keep dense |

### Stage 3: Hybrid Architecture

Construct mixed model:
- Layers 0, 11: Dense attention (keep full power)
- Layers 4-7: InAttention (save VRAM)
- Layer 10: Hybrid (test both, pick best)

**Expected Result**: **50-60% VRAM saving**, negligible accuracy loss.

---

## Success Criteria

| Criterion | Target | Pass/Fail |
|-----------|--------|-----------|
| **Single-Layer VRAM Reduction** | >20% | - |
| **PPL Impact (Layer 10)** | <±1% | - |
| **Inference Speedup** | >1.5x | - |
| **Hybrid Model VRAM** | >50% | - |
| **Hybrid Model Accuracy** | >99.5% | - |

---

## Code Structure

```
interventions/inattention_conversion/
├── code/
│   ├── attention_replace.py     # Hook + attention swap logic
│   ├── inattention_layer.py     # InAttention module implementation
│   ├── hybrid_model.py           # Mixed dense/InAttention model
│   └── validate_inattention.py   # Benchmark suite
└── experiments/
    ├── single_layer/            # Test Layer 10 conversion
    ├── progressive/             # Test layers 4-10
    └── hybrid/                  # Final hybrid model
```

---

## Deployment Path

**After Phase 6 Validation (PPL: -0.11%)**

1. **Week 1**: Implement InAttention layer, validate on Layer 10
2. **Week 2**: Progressive layer testing (4-7, then 8-10)
3. **Week 3**: Build hybrid model, benchmark on Mistral-7B
4. **Week 4**: Deploy to production (if VRAM >50% savings)

---

## Integration with Phase 8 (Mistral-7B)

Once GPU is available:
1. Run Phase 8: Validate 0.98x scaling on Mistral-7B
2. **Immediately apply InAttention**: Layers 8-15 (mid-depth, analogous to 4-7 in GPT-2)
3. Measure combined savings: 0.98x scaling + InAttention

**Expected**: **65-75% compute reduction** on Mistral-7B inference.

---

## Why This Matters for Your Project

✅ **Directly addresses the proposal goal**: "5x compute reduction"  
✅ **Foundation laid in Phase 6**: Elasticity proven, safe to modify  
✅ **Architectural insight**: Linear attention scales better to long contexts  
✅ **Research contribution**: Novel hybrid dense/linear architecture  

---

## References

- **Paper**: InAttention (XXXX.XXXXX) — Linear context scaling
- **Phase 6**: Elasticity validation (foundation for safe replacement)
- **Phase 8**: GPU environment (needed for Mistral-7B InAttention)
- **Related**: Quantization (can stack with InAttention for additional gains)

---

## Recommended Reading

1. **InAttention paper** (~30 min): Understand core mechanism
2. **Attention is All You Need** (~20 min): Refresh attention mechanism
3. **TransformerLens hooks** (~15 min): Understand attention override patterns
