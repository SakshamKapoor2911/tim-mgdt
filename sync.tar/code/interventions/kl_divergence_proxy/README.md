# KL Divergence Proxy: Fast Layer Sensitivity Estimation

**Status**: 📋 READY FOR IMPLEMENTATION  
**Priority**: 🟡 MEDIUM (Foundation for downstream compression)  
**Target Model**: GPT-2 (validate), Mistral-7B (scale)  
**Expected Impact**: **100x speedup in sensitivity profiling**, enable real-time compression decisions

---

## Objective

Replace expensive downstream task evaluation with **cheap KL divergence proxies** to predict layer sensitivity in **<1 second per layer** (vs. hours for full evaluation).

**Key Insight from Research Doc**: 
> "Use KL divergence between teacher (dense) and student (compressed) layer outputs on small calibration set to predict true sensitivity."

---

## The Problem: Costly Sensitivity Profiling

### Current Approach (Slow)
```
For each layer:
  1. Compress/ablate layer
  2. Run full dataset evaluation  --> ~10 minutes per layer
  3. Measure downstream accuracy   --> ~1 hour for 12 layers
```

### Proposed Approach (Fast)
```
For each layer:
  1. Hook teacher & student layer outputs
  2. Compute KL-div on 100-sample calibration set  --> 1 second
  3. Rank layer importance                          --> 1 second total for all layers
```

---

## The KL Divergence Proxy Concept

### Hypothesis

> "Layers that produce **similar** outputs (low KL) after compression are safe to compress.  
> Layers that produce **different** outputs (high KL) are critical and risky to compress."

### Mathematical Formulation

For a compressed layer (e.g., Layer 10 at 0.98x scale):

$$\text{KL}(P_{\text{dense}} || P_{\text{compressed}}) = \sum_{i} P_{\text{dense}}(i) \log \frac{P_{\text{dense}}(i)}{P_{\text{compressed}}(i)}$$

Where:
- $P_{\text{dense}}$ = softmax over dense layer activations
- $P_{\text{compressed}}$ = softmax over scaled layer activations
- Low KL = safe to modify
- High KL = critical, avoid modification

---

## Supporting Evidence from Research Doc

From **"Cheap Sensitivity Proxies for Layer Selection"** section:

> "Idea: Replace per-layer downstream accuracy tests with faster proxies (e.g., KL divergence between teacher/student attention outputs on a small calibration set). Validate how well proxies predict true sensitivity."

### Prior Art

- **AAAI 2023** ("Compressing Transformers"): Activation features are low-rank
- **LLM-Pruner**: Uses limited calibration data + importance metrics
- **Layer-wise Distillation (TED)**: KL divergence measures redundancy

---

## Experimental Design

### Phase A: Proxy Validation (GPT-2)

1. **Calibration Setup**
   - Use n=100 samples from WikiText-2
   - Compute baseline layer outputs (dense model)

2. **Compression Tests**
   - Apply 0.98x scaling to Layer 10 (from Phase 6)
   - Compute compressed layer outputs

3. **KL Divergence Metrics**
   - Compute KL-div between dense and scaled outputs
   - Record per-sample, per-head, and aggregate statistics

4. **Validation Against Ground Truth**
   - Compare KL-div ranking to Phase 4's sensitivity analysis
   - Measure correlation (should be ρ > 0.80 expected)

5. **Efficiency Benchmark**
   - Time for calibration: ?ms
   - Time for KL computation: ?ms
   - Speedup vs. full evaluation: ?x

---

### Phase B: Multi-Layer Ranking (GPT-2)

1. **Sensitivity Ranking**
   - Apply light compression to all 12 layers
   - Compute KL-div for each
   - Rank layers from most-to-least sensitive

2. **Correlation with Phase 4**
   - Ground truth from Phase 4: Layer 11 most critical, Layer 10 second
   - KL-rank should match ground truth ranking

3. **Cost-Benefit Analysis**
   - Full evaluation: ~60 minutes
   - KL proxy: ~30 seconds
   - **Speedup**: 120x

---

### Phase C: Generalization Test (Mistral-7B)

Once Phase 8 GPU is available:
1. Apply same KL proxy methodology to Mistral-7B layers
2. Validate correlations hold at larger scale
3. Build reusable KL-proxy framework

---

## Expected Outcomes

### Outcome A: KL Divergence Works (Likely >70% chance)

| Metric | Target | Expected |
|--------|--------|----------|
| Correlation with Phase 4 | ρ > 0.80 | ✓ High |
| Top-5 layers ranking | 100% agreement | ✓ Likely |
| Calibration set size | <500 samples | ✓ Feasible |
| Computation time | <1 second | ✓ Achievable |

**Implication**: Deploy KL proxy as standard sensitivity metric.

### Outcome B: KL Underperforms

- ⚠️ Doesn't correlate well with ground truth
- Possible causes: nonlinear layer interactions, attention artifacts
- **Next Step**: Combine with alternative metrics (Fisher info,Jacobian)

---

## Code Structure

```
interventions/kl_divergence_proxy/
├── code/
│   ├── kl_divergence.py         # Core KL-div computation
│   ├── calibration_manager.py    # Calibration set handling
│   ├── layer_ranking.py          # Sensitivity ranking pipeline
│   ├── validate_kl_proxy.py      # Compare to Phase 4 ground truth
│   └── benchmark_efficiency.py   # Speed benchmarks
└── experiments/
    ├── single_layer/            # Validate Layer 10 KL-div
    ├── all_layers/              # Full ranking test
    └── correlation/             # Compare to Phase 4
```

---

## Success Criteria

| Criterion | Target | Pass/Fail |
|-----------|--------|-----------|
| **Correlation with Phase 4** | ρ > 0.75 | - |
| **Top-K Layers Agreement** | >90% | - |
| **Computation Time per Layer** | <100ms | - |
| **Calibration Samples Needed** | <500 | - |
| **Total Ranking Time** | <10 seconds | - |

---

## Integration Roadmap

### Immediate (After Phase 6)

1. Implement KL divergence for Layer 10 (validate against Phase 4 ΔCE)
2. Benchmark efficiency vs. full evaluation

### Short-term (After Phase 7)

1. Extend to all 12 layers
2. Build automated ranking pipeline
3. Compare to Phase 4 sensitivity_results

### Medium-term (With Phase 8 GPU)

1. Test on Mistral-7B layers
2. Validate generalization across architectures

### Long-term (Downstream Interventions)

1. Use KL rankings for safe layer selection in quantization
2. Use as input to dynamic pruning algorithms
3. Build automatic "safe compression map" for any model

---

## Why This Matters

✅ **Solves the "expensive profiling" problem**: Enable real-time compression decisions  
✅ **Enables scalable pipeline**: Can rank 32+ layers in <10 seconds  
✅ **Foundation for automation**: Input to downstream interventions  
✅ **Research contribution**: First comprehensive validation of KL proxies on transformers  

---

## Related Interventions

| Intervention | Uses KL Proxy |
|--------------|--------------|
| InAttention | To identify safe layers to convert |
| Quantization Maps | To build safe quantization blueprint |
| Low-Rank Compression | To identify compressible layers |
| Dynamic Early Exit | To identify early-exit candidate layers |

---

## References

- **Research**: "Cheap Sensitivity Proxies for Layer Selection" from research doc
- **Paper**: AAAI 2023 "Compressing Transformers"
- **Phase 4**: Ground truth sensitivity_results_500samples.json
- **Phase 6**: Base elasticity validation (Layer 10 at 0.98x)

---

## Recommended Reading

1. **KL Divergence tutorial** (~20 min): Understand divergence measure
2. **Attention analysis papers** (~30 min): How attention encodes information
3. **Sensitivity analysis methods** (~20 min): Alternative sensitivity metrics
