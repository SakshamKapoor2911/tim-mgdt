# Quantization Maps: Layer-wise Safe Quantization Blueprint

**Status**: 📋 READY FOR IMPLEMENTATION  
**Priority**: 🔴 HIGH (Largest potential model size reduction)  
**Target Model**: GPT-2 (validate), Mistral-7B (scale)  
**Expected Impact**: **75-85% model size reduction** (FP32→8-bit/4-bit), 2-3x inference speedup

---

## Objective

Build a **"Safe-Compression Map"** that specifies exactly which layers can be safely quantized to 8-bit, 4-bit, or mixed precision without significant accuracy loss.

**Key Insight from Research Doc**: 
> "Layer/Module Sensitivity Profiling + Safe-Compression Maps. Produces publishable diagnostic contribution and helps explain dataset-dependent behavior."

---

## The Quantization Problem

### Key Challenge
Different layers have different quantization sensitivity:
- **Layer 11 (output layer)**: Very sensitive, needs FP32 or 16-bit
- **Layer 5 (mid-layer)**: Robust to 8-bit quantization
- **Layer 2 (early layer)**: May tolerate 4-bit quantization

### Current Approach (Trial-and-Error)
```
Quantize entire model to 8-bit
→ Evaluate PPL
→ If bad, try 16-bit
→ If good, try 4-bit on specific layers
→ Hours of manual testing
```

### Proposed Approach (Principled)
```
1. Profile sensitivity per layer (using KL divergence)
2. Build quantization map: Layer_i → Precision_i
3. Apply mixed-precision scheme
4. Evaluate once
```

---

## Quantization Strategy

### Stage 1: Layer Sensitivity Profiling

For each layer, test quantization at different bit-widths:

| Layer | FP32 | FP16 | 8-bit | 4-bit | Recommended |
|-------|------|------|-------|-------|-------------|
| 0 | Baseline | -0.1% | -0.3% | -0.8% | **8-bit** |
| 5 | Baseline | -0.05% | -0.2% | **-2%** | **8-bit** |
| 10 | Baseline | -0.3% | **-1.5%** | -8% | **FP16** |
| 11 | Baseline | **-0.5%** | -3% | -15% | **FP32 or FP16** |

### Stage 2: Build Quantization Blueprint

```
Quantization Map (GPT-2):
├── Layer 0-3:   8-bit (robust early extraction)
├── Layer 4-9:   8-bit (safe compression zone)
├── Layer 10:    16-bit (critical from Phase 6)
└── Layer 11:    32-bit (output quality control)

Expected Size: 
  - FP32 baseline: 468 MB
  - Mixed-precision: 117 MB (75% reduction!)
```

### Stage 3: Validation & Deployment

1. **Apply mixed-precision quantization** according to map
2. **Evaluate on WikiText-2**: Should see <1% PPL impact
3. **Benchmark inference speed**: Expect 2-3x speedup
4. **Test downstream tasks** (Phase 9): Ensure task quality maintained

---

## Implementation Strategy

### Phase A: Sensitivity Profiling (GPT-2)

1. **Setup**
   - Use base GPT-2 model from Phase 6
   - Calibration set: 100 WikiText-2 samples

2. **Quantization Tests**
   - For each layer, test: FP32, FP16, 8-bit, 4-bit
   - Measure PPL for each configuration
   - Record per-layer sensitivity

3. **Correlation with Phase 4**
   - Compare sensitivity rankings to Phase 4 ground truth
   - Expected: 8-bit-sensitive layers = Phase 4 critical layers

4. **Output: Quantization Sensitivity Table**
   ```
   Layer | Sensitive to 8-bit? | Sensitive to 4-bit? | Recommendation
   ```

### Phase B: Build Mixed-Precision Model

1. **Create Quantization Map** from sensitivity table
2. **Select quantization library**: PyTorch quantization, ONNX QDQ, or bitsandbytes
3. **Apply per-layer precision**
4. **Validate model runs end-to-end**

### Phase C: Evaluate Impact

1. **Baseline**: FP32 model PPL
2. **Mixed-precision**: Apply quantization map
3. **Measure**:
   - PPL delta (target: <1%)
   - Model size (target: 75% reduction)
   - Inference speed (target: 2-3x speedup)
   - Quantization-specific errors

### Phase D: Scale to Mistral-7B (Post-GPU)

1. Repeat profiling on 32-layer model
2. Build 32-layer quantization map
3. Validate at larger scale

---

## Code Structure

```
interventions/quantization_maps/
├── code/
│   ├── quantization_profiler.py   # Test layer sensitivity
│   ├── blueprint_builder.py        # Build quantization map
│   ├── mixed_precision_model.py    # Apply quantization scheme
│   ├── validate_quantization.py    # Evaluate accuracy impact
│   └── benchmark_speedup.py        # Measure inference improvements
└── experiments/
    ├── sensitivity_profile/       # Per-layer bit-width tests
    ├── blueprint/                 # Quantization map generation
    ├── mixed_precision/           # Apply & validate mixed-precision
    └── deployment/                # Final benchmarks
```

---

## Expected Outcome: Quantization Blueprint

**Example Output**:

```markdown
# GPT-2 Quantization Blueprint

## Summary
- Baseline Model Size: 468 MB (FP32)
- Quantized Model Size: 117 MB
- Size Reduction: 75%
- PPL Impact: +0.23%
- Inference Speedup: 2.8x

## Per-Layer Precision

| Layer | Param Count | Precision | Size | Impact |
|-------|------------|-----------|------|--------|
| 0     | 590K       | INT8      | 590K | -0.1% |
| 1     | 590K       | INT8      | 590K | -0.05% |
...
| 10    | 590K       | FP16      | 1.2M | -0.3% |
| 11    | 590K       | FP32      | 2.4M | -0.1% |

## Deployment Steps

1. Load GPT-2
2. Apply quantization from blueprint (layer-wise)
3. Run inference at 2.8x speedup with 75% smaller model
```

---

## Success Criteria

| Criterion | Target | Pass/Fail |
|-----------|--------|-----------|
| **Model Size Reduction** | >70% | - |
| **PPL Impact** | <±1% | - |
| **Inference Speedup** | >2x | - |
| **Per-Layer Profiling Time** | <2 hours | - |
| **Blueprint Reproducibility** | 100% (same on re-run) | - |

---

## Why This Matters

✅ **Largest impact intervention**: 75% size reduction  
✅ **Directly addresses proposal**: Model compression  
✅ **Production-ready**: No retraining, instant deployment  
✅ **Diagnostic value**: Blueprint explains which layers need precision  
✅ **Reproducible**: Quantization map is reusable across models  

---

## Integration with Other Interventions

| Intervention | Synergy | Combined Impact |
|--------------|---------|-----------------|
| **Phase 6 (0.98x scaling)** | Can combine (scaling + quantization) | 75% size + better convergence |
| **Low-Rank Compression** | Can stack (for additional 5-10%) | 80-85% total size reduction |
| **InAttention** | Stack entirely (size + memory) | 85-90% reduction on all fronts |
| **KL Divergence** | Use to identify safe layers | Data-driven quantization |

---

## Roadmap

### Immediate (Post-Phase 6)
1. Profile Layer 10 quantization sensitivity
2. Validate correlation with Phase 4 criticality

### Short-term (Post-Phase 7)
1. Complete profiling for all 12 layers
2. Build comprehensive quantization blueprint
3. Deploy mixed-precision model

### Medium-term (Post-Phase 8 GPU)
1. Profile Mistral-7B quantization sensitivity
2. Build 32-layer quantization blueprint
3. Validate on large-scale models

### Long-term (Post-Phase 9)
1. Evaluate quantization impact on downstream tasks
2. Publish "Safe Quantization Maps" as reusable artifact
3. Release tool for automated quantization profiling

---

## References

- **Research Doc**: "Layer/Module Sensitivity Profiling + Safe-Compression Maps"
- **Phase 4**: Sensitivity data (ground truth for layer criticality)
- **Phase 6**: Elasticity baseline (0.98x scaling shows flexibility)
- **KL Divergence**: Use as fast proxy for layer ranking
- **Related Papers**: 
  - "A Survey on Model Compression for Large Language Models"
  - "Energy-Efficient Transformer Inference"

---

## Recommended Reading

1. **Quantization basics** (~20 min): INT8, mixed-precision concepts
2. **Sensitive layer analysis** (~20 min): Which layers to quantize
3. **PyTorch/ONNX quantization** (~30 min): Implementation tools
