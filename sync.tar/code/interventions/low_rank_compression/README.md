# Low-Rank Compression: Compressing Activation Features

**Status**: 📋 READY FOR IMPLEMENTATION  
**Priority**: 🟡 MEDIUM (Foundation for model size reduction)  
**Target Model**: GPT-2 (validate), Mistral-7B (scale)  
**Expected Impact**: **20-40% model size reduction**, 1.5-2x inference speedup

---

## Objective

Leverage the insight that **transformer activations are low-rank even when weights are full-rank** to compress hidden representations without retraining.

**Key Insight from Research Doc**: 
> "Instead of compressing weights, compress activation features, which are shown to be low-rank across layers."

---

## The Key Paper: AAAI 2023

**Reference**: Compressing Transformers: Features Are Low-Rank, but Weights Are Not! (AAAI 2023)

### Core Finding

| Component | Rank Property | Compressibility |
|-----------|---------------|-----------------|
| **Weights (W)** | Full-rank (~768) | ❌ Hard to compress |
| **Activations (A)** | Low-rank (~50-100) | ✅ Easy to compress |
| **Implication** | - | Focus on feature compression, not weight compression |

---

## Why Activation Compression Works

### Standard Low-Rank Compression (CNNs)
```
Weight matrix W: [H_out × H_in] ≈ U @ S @ V^T  (low-rank decomposition)
Problem: Transformer weights are full-rank, factorization fails
```

### Feature Compression (Transformers)
```
Hidden state A: [seq × H_hidden] = reduced to [seq × H_compressed]
Method: Per-layer local low-rank compression based on activation structure
Problem: None identified (activations are naturally low-rank!)
```

---

## Implementation Strategy

### Stage 1: Rank Analysis (GPT-2)

1. **Activation Profiling**
   - Collect activations for Layer 10 on 500 WikiText-2 samples
   - Compute SVD (Singular Value Decomposition)
   - Determine effective rank (where ~90% variance preserved)

2. **Question to Answer**
   - "At what dimension can we compress Layer 10's activations while losing <1% downstream accuracy?"
   - Expected: H_compressed ≈ 512-600 (vs. original 768, ~25% compression)

3. **Per-Layer Sensitivity**
   - Repeat rank analysis for all 12 layers
   - Find layers where compression is safe vs. layers where it's risky

### Stage 2: Compression Mapping (GPT-2)

1. **Build Linear Projectors**
   - For each layer deemed safe for compression
   - Create projection matrices: P_compress and P_reconstruct
   - P_compress: [768 → 512], P_reconstruct: [512 → 768]

2. **Compression Insertion**
   - After Layer i: A_compressed = A @ P_compress
   - Before Layer i+1: A_reconstructed = A_compressed @ P_reconstruct

3. **Test on Restricted Layers**
   - Compress activations in Layers 4-9 (mid-depth, less critical)
   - Keep Layers 0-3, 10-11 uncompressed (early/late layers more critical)

4. **Evaluation**
   - PPL impact: expected <3%
   - Model size reduction: ~15-25%
   - Inference speedup: ~1.3x (less computation per layer)

---

### Stage 3: Hybrid Compression with Phase 6

**Combine with 0.98x scaling**:

| Layer | Strategy | Expected Size Reduction | Expected Speed |
|-------|----------|------------------------|------------------|
| 0-3 | Uncompressed | 0% | 1x |
| 4-7 | Low-rank compress | 20±5% | 1.3x |
| 8-10 | Phase 6 scaling (0.98x) + slight compress | 5% | 1.1x |
| 11 | Uncompressed | 0% | 1x |

**Combined Savings**: ~10-15% model size, ~1.2x inference speedup.

---

### Stage 4: Scale to Mistral-7B

Once GPU available:
1. Analyze activation ranks in Mistral-7B (32 layers)
2. Design compression map for 32-layer architecture
3. Target: 20-30% size reduction without retraining

---

## Success Criteria

| Criterion | Target | Pass/Fail |
|-----------|--------|-----------|
| **Effective Rank** | 50-65% of original | - |
| **PPL Impact (GPT-2)** | <±3% | - |
| **Model Size Reduction** | >15% | - |
| **Inference Speedup** | >1.2x | - |
| **Per-Layer Rank Analysis** | < 1 hour total | - |

---

## Code Structure

```
interventions/low_rank_compression/
├── code/
│   ├── rank_analysis.py          # SVD analysis of activations
│   ├── projector_builder.py       # Compression matrix creation
│   ├── compression_pipeline.py    # Insert/remove projectors
│   ├── validate_compression.py    # Evaluate PPL impact
│   └── benchmark_speedup.py       # Measure inference speed
└── experiments/
    ├── rank_analysis/            # SV decomposition results
    ├── single_layer/             # Compress Layer 10 only
    ├── multi_layer/              # Compress Layers 4-9
    └── hybrid_compression/       # Combined with 0.98x scaling
```

---

## Deployment Roadmap

### Week 1: Rank Analysis
- Collect activations for all layers
- Compute SVD, find effective ranks
- Identify safe vs. risky layers

### Week 2: Single-Layer Compression
- Build projectors for Layer 10
- Insert compression, evaluate PPL
- Benchmark speed improvements

### Week 3: Multi-Layer Compression
- Extend to Layers 4-9
- Measure combined size reduction
- Validate hybrid with 0.98x scaling

### Week 4: Mistral-7B (Post-GPU)
- Repeat analysis on 32-layer model
- Validate generalization

---

## Integration with Other Interventions

| Intervention | Synergy |
|--------------|---------|
| **Phase 6 (0.98x scaling)** | Stack for combined 15-20% size reduction |
| **InAttention** | Not compatible (InAttention reduces memory, low-rank reduces params) |
| **Quantization** | Can stack: compress activations then quantize |
| **KL Divergence Proxy** | Use KL-div to identify safest layers to compress |

---

## Why This Matters

✅ **Addresses proposal**: "Model compression via activation rebalancing"  
✅ **Practical**: No retraining needed, instant deployment  
✅ **Layered approach**: Can selectively compress 4-9 layers without touching critical ones  
✅ **Research contribution**: First systematic study of transformer activation rank in context of compression  

---

## References

- **Paper**: Compressing Transformers: Features Are Low-Rank, but Weights Are Not (AAAI 2023)
- **Phase 6**: Base elasticity (0.98x scaling) shows model is flexible
- **KL Divergence**: Use to identify safest layers for compression
- **Research Doc**: "Low-rank activation compression" section

---

## Recommended Reading

1. **Low-rank decomposition tutorial** (~20 min): SVD and rank concepts
2. **AAAI 2023 paper** (~40 min): Core activation-based compression insights
3. **Activation analysis tools** (~15 min): How to compute effective rank
