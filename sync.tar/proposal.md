# Diagnostic Proxies for Accelerated Compression: Predicting Layer Sensitivity via Geometric and Causal Manifolds

**Author(s):** Algoverse (Team MGDT)  
**Date:** March 1, 2026

---

## Abstract
Modern Large Language Model (LLM) compression techniques, such as structured pruning [2] and attention-to-linear conversion, are currently bottlenecked by the requirement for exhaustive downstream evaluation to identify safe intervention targets [6]. This process is computationally prohibitive for models exceeding 7B parameters. We introduce a **Predictive Ranking Framework** that utilizes cheap, forward-pass mechanistic signals to estimate layer sensitivity. Our approach employs a triad of diagnostic proxies: **Randomized Effective Dimension (ED)** for structural capacity [7], **Logit Jacobian Norms** for functional leverage, and **Normalized Area Under the Drift Curve (nAUDC)** for error propagation [4]. We hypothesize that these metrics can rank layer sensitivity with high Spearman correlation (\rho > 0.7) to ground-truth performance degradation, enabling a **5x reduction** in compression planning compute. By shifting from behavioral "trial-and-error" to structural diagnostics, we provide a scalable, systems-acceleration path for model optimization on commodity hardware.

---

## 1 Introduction

### 1.1 The Problem: The Exhaustive Evaluation Bottleneck
The deployment of Large Language Models on edge devices necessitates aggressive compression. However, identifying which layers are "safe" to prune or modify currently requires running the entire model through a battery of benchmarks for every candidate intervention. In a 32-layer model like Llama-2-7B, this exhaustive search can exceed 100 GPU hours, rendering it inaccessible for small research teams and real-time optimization [6].

### 1.2 The Opportunity: From Behavioral to Structural Diagnostics
Recent advances in mechanistic interpretability suggest that layers do not contribute equally to a model's logic [4]. Some layers act as high-bandwidth "highways" for information, while others are "specialists" operating in low-dimensional subspaces. We propose that these internal structural properties—visible during a single forward pass—can predict sensitivity more effectively than traditional black-box heuristics [3].

---

## 2 Methodology

### 2.1 Formalism
Let $M$ be a transformer model with $D$ layers. For an intervention $\Delta$ at layer $L_i$, we denote the modified model as $M(L_i, \Delta)$. We define the sensitivity $S(L_i, \Delta)$ as the degradation in downstream task performance. Our goal is to derive a proxy $P(L_i)$ such that $Rank(P(L_i)) \approx Rank(S(L_i, \Delta))$, minimizing the wall-clock time required for $P(L_i)$ relative to $S(L_i, \Delta)$.

### 2.2 The Proxy Triad: Metric Orthogonality
We define three orthogonal metrics that capture the "geometry," "leverage," and "stability" of a layer. We select these specifically because they address distinct failure modes of single-metric diagnostics [1]:

1.  **Geometric (Randomized ED):** Measures **Structural Capacity**. We apply `torch.svd_lowrank` to determine the **Effective Dimension (ED)** required to explain 95% of the activation variance [7]. This identifies "Information Highways" prone to interference during compression.
2.  **Causal (Logit Jacobian):** Measures **Functional Leverage**. We compute the $L_2$ norm of the gradient of final logits with respect to the layer's output: $||\nabla_{h_{L_i}} \text{Logits}||_2$. This prevents the misclassification of "Critical Specialists"—layers that are structurally sparse but causally dominant.
3.  **Propagation (nAUDC):** Measures **Systemic Resilience**. We track the cumulative cosine distance of the residual stream in subsequent layers $j > i$ following an intervention [4]:
    $$nAUDC(L_i) = \frac{1}{D-i} \sum_{j=i+1}^D (1 - \text{CosSim}(r_j^{orig}, r_j^{mod}))$$
    This accounts for the model's ability to "Self-Correct" or reject transient noise.

### 2.3 The Parsimony Principle: Why Not More?
To maintain the **Systems ROI**, we adhere to the Principle of Parsimony. While high-fidelity mechanistic signals (e.g., Path Patching or SAE feature ablation [5]) exist, their computational overhead violates the "cheap proxy" constraint. Our triad remains within $O(\text{Forward/Backward Pass})$ complexity, ensuring a 5x compute reduction over exhaustive evaluation.

---

## 3 Research Plan & Strategy
To ensure submission readiness for top-tier systems/interpretability workshops (e.g., NeurIPS, ICML), we adopt a tiered execution plan:
- **Systems ROI Focus:** We prioritize proving the "Compute Saved vs. Accuracy Retained" trade-off.
- **Statistical Rigor:** We utilize 1,000 bootstrap iterations over evaluation items to calculate **95% Confidence Intervals** for all Spearman $\rho$ values.
- **Significance Testing:** We employ **Steiger’s Z-test** to determine if our proxy ensemble statistically outperforms naive baselines such as "Layer Depth" and "Activation Norm."

---

## 4 Experiments

### 4.1 Experimental Matrix
To validate the framework's robustness across architectures and tasks, we will execute a 2x3x2 experimental matrix:
*   **Models:** Llama-2-7B [2], Mistral-7B [1].
*   **Tasks:** Reasoning (ARC-Challenge), Summarization (CNN/DailyMail), Mathematics (GSM8K).
*   **Interventions:** Structured Pruning, Attention-to-Linear Swap.

### 4.2 Experimental Setup
*   **Calibration Set:** 500 diverse samples from WikiText-2 [1].
*   **Hooks:** We utilize **TransformerLens** for surgical activation extraction.

---

## 5 Discussion: The Geometry-Causality Gap
A structurally sparse layer (Low ED) may still house a critical logic gate. We distinguish between transient noise and catastrophic error propagation [4], acknowledging that Transformers possess internal self-correction capabilities [8].

---

## 6 Conclusion
Diagnostic Proxies democratize mechanistic interpretability by converting complex internal signals into fast, geometric interventions for model compression. By moving from brute-force search to surgical diagnostics, this methodology paves the way for AI systems architecturally optimized for efficiency.

---

## References
[1] Sun, M., et al. (2023). "A Simple and Effective Pruning Approach for Large Language Models." ICML.  
[2] Ma, X., et al. (2023). "LLM-Pruner: On the Structural Pruning of Large Language Models." NeurIPS.  
[3] Kornblith, S., et al. (2019). "Similarity of Neural Network Representations Revisited." ICML.  
[4] Elhage, N., et al. (2021). "A Mathematical Framework for Transformer Circuits." Anthropic.  
[5] Bricken, T., et al. (2023). "Towards Monosemanticity: Decomposing LLMs With Dictionary Learning." Anthropic.  
[6] HotInfra (2024). "Optimizing Transformer Inference with Selective Distillation."  
[7] Yang, Y., et al. (2023). "Compressing Transformers: Features Are Low-Rank, but Weights Are Not!" AAAI.  
[8] Sun, A., et al. (2025). "Circuit Stability in Reasoning Paths." arXiv. 
