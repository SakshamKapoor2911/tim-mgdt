# Implementation Plan: TIM-MGDT (Diagnostic Proxies for Accelerated Compression)

This document outlines the phased development for implementing the **Predictive Ranking Framework** to estimate layer sensitivity in LLMs. The initial phase focuses on a single LLM (Mistral-7B-v0.1) and a simple intervention (Layer-wise Activation Ablation) to establish a baseline sensitivity ranking.

## 1. Project Overview & Objective
To validate the **Proxy Triad** (Geometric, Causal, and Propagation metrics) as reliable indicators of layer sensitivity compared to traditional, computationally expensive evaluation benchmarks.

### Why Proxies > Perplexity (PPL)?
While PPL is our "Medium-Fidelity Ground Truth," the Proxy Triad is superior for production and deep research because:
1.  **Mechanistic Insight ("Why" vs. "What"):** PPL only tells us *that* a layer is sensitive (behavioral). Proxies explain *how* (mechanistic): **ED** identifies structural "highways," **Jacobian** flags "functional specialists," and **nAUDC** measures "systemic resilience."
2.  **The Efficiency Gap ($O(1)$ vs. $O(L)$):** Calculating PPL for ground truth requires $L$ separate forward passes (one per layer ablation). The Proxy Triad can be extracted in a **single diagnostic forward/backward pass**, providing a ~32x speedup for a 32-layer model.
3.  **Geometry-Causality Gap:** Proxies distinguish between transient noise and catastrophic error propagation, which a flat PPL score cannot do.

- **Primary Model:** Mistral-7B-v0.1 (via HuggingFace / TransformerLens).
- **Primary Intervention:** **Layer-wise Activation Ablation** (setting layer outputs to zero/mean) to measure immediate performance degradation.
- **Metric Triad:** Randomized ED, Logit Jacobian Norms, and nAUDC.

## 2. Intended Project Structure
```text
implementation/
├── data/                      # Dataset samples (WikiText-2, etc.)
├── models/                    # Model loading and hook wrappers
│   └── model_wrapper.py       # Wrapper for TransformerLens/HF
├── metrics/                   # Core Proxy Triad implementation
│   ├── geometric_ed.py        # Randomized Effective Dimension (SVD)
│   ├── causal_jacobian.py     # Logit Jacobian Norm calculation
│   └── propagation_naudc.py   # nAUDC (Error propagation)
├── interventions/             # Experimental modifications
│   └── ablation.py            # Simple Layer-wise Activation Ablation
├── experiments/               # Run scripts and logging
│   └── baseline_sensitivity.py # Script to correlate proxies with ground truth
├── visualizations/            # Plotting and manifold analysis
└── Plan.md                    # This document
```

## 3. Development Stages & Tasks

### Phase 1: Environment & Single LLM Setup
- [ ] Setup virtual environment and install dependencies (`torch`, `transformers`, `transformer_lens`, `scipy`).
- [ ] Implement `model_wrapper.py` to load **Mistral-7B-v0.1** with activation hooks.
- [ ] Load a calibration set (500 samples from WikiText-2).

### Phase 2: Ground Truth Mapping (Medium-Fidelity)
- [ ] Implement `ablation.py` for Layer-wise Activation Ablation.
- [ ] **Strategy:** Instead of full benchmarks, run PPL checks on a 512-token calibration set from WikiText-2.
- [ ] Generate a "Ground Truth" sensitivity ranking (32 layers ranked by $\Delta PPL$).

### Phase 3: Implementing the Proxy Triad
- [ ] **Geometric:** Implement `geometric_ed.py` using `torch.svd_lowrank`.
- [ ] **Causal:** Implement `causal_jacobian.py` for $||\nabla_{h_{L_i}} \text{Logits}||_2$.
- [ ] **Propagation:** Implement `propagation_naudc.py` for cumulative cosine drift.

### Phase 4: Correlation & Decision Matrix
- [ ] Calculate Spearman Correlation ($\rho$) between Proxies and $\Delta PPL$.
- [ ] **Conditional Path A (Success):** If $\rho > 0.7$, proceed to Phase 5 (Full Pruning Experiments).
- [ ] **Conditional Path B (Refinement):** If $0.4 < \rho < 0.7$, perform Feature Ablation to see which of the triad is the "Weak Link."
- [ ] **Conditional Path C (Pivot):** If $\rho < 0.4$, implement **Fallback Metrics** as detailed below.

## 4. Fallback Metrics & Future Scope (Pivot Options)
In the event of Path C, we will pivot to higher-fidelity (yet still cheap) diagnostics:
1. **KL Divergence (KLD):** Measuring the distributional shift in final logits following layer ablation.
2. **Representation Drift:** Calculating the cumulative Euclidean or Cosine distance of the residual stream at the final layer.
3. **Centered Kernel Alignment (CKA):** To detect redundant layer representations by comparing layer-wise similarity matrices.
4. **Fisher Information / Hessian Trace:** Estimating parameter-level sensitivity using the diagonal of the Fisher Information Matrix.
5. **Activation Sparsity ($L_0$):** Identifying "dead" or low-utility neurons that contribute little to the model's predictive variance.

## 5. Progress Tracking
- [x] **Phase 1: Setup** (Environment & Modular Architecture defined)
- [x] **Phase 2: Ground Truth Mapping** (Completed on GPT-2)
- [x] **Phase 3: Proxy Implementation** (Triad + Advanced Proxies)
- [x] **Phase 4: Decision Matrix Execution** (High correlation confirmed)
- [x] **Phase 5: Advanced Compression & Recovery** (Circuit Analyzer, Jacobian Pruning)
- [x] **Phase 6: Integration Validation** (End-to-end pipeline validated)
- [ ] **Phase 7: Alternative Corpus Validation** (Wikitext-103, BookCorpus)
- [ ] **Phase 8: Mistral-7B/Llama-8B Scaling** (Moving to large models)
- [ ] **Phase 9: Downstream Task Evaluation** (MMLU, GSM8K)

## 6. Current Status (April 2026)
The project has successfully validated the Proxy Triad on GPT-2. We are now refactoring the codebase to support seamless scaling to Mistral-7B and Llama-3-8B while maintaining strict output isolation and experimental provenance.

### Key Accomplishments:
1.  **Phase 5 Completion:** Demonstrated that Advanced Proxies (Head Jacobian, Circuit Analyzer) can guide pruning with minimal performance loss.
2.  **Phase 6 Validation:** Integrated all components into a robust validation pipeline.
3.  **Refactor Initiation:** Implementing `REFACTOR_MAP_PRE_PHASE8.md` to prepare for large-scale experiments.

---
*Last Updated: 2026-03-08*
