# TIM-MGDT: Remote GPU Execution Guide

## 1. Environment Topology
- **Connectivity:** Wireguard VPN + SSH.
- **Hardware:** 2x NVIDIA RTX 3090 (24GB VRAM each).
- **Target Models:** Mistral-7B, Llama-3-8B, Llama-2-7B/13B (see registry in `tests/run_remote_llm.py`).

## 2. Remote Setup (Run Once)

```bash
git clone https://github.com/SakshamKapoor2911/tim-mgdt.git
cd tim-mgdt

python -m venv venv
source venv/bin/activate   # Linux
# .\venv\Scripts\activate  # Windows

pip install -r requirements.txt
pip install bitsandbytes accelerate

# Gated models (Llama) — set once per session
export HF_TOKEN=your_huggingface_token
huggingface-cli login
```

## 3. Single-File Multi-LLM Testing

**Toggle models** in `tests/run_remote_llm.py` (`DEFAULT_MODELS`) or pass CLI flags:

```bash
# Default models (mistral-7b + llama-3-8b)
python tests/run_remote_llm.py

# Explicit selection
python tests/run_remote_llm.py --models mistral-7b,llama-3-8b --precision fp16 --num-samples 100

# List all supported models
python tests/run_remote_llm.py --list-models

# Synthetic GPU sweep (no HF download)
python tests/test_phase10_comprehensive.py
```

Results land in `experiments/phase10/` as `{model_key}_remote_*.json`.

## 4. Dual 3090 Layout

### Choice A: One model per GPU (recommended)
Run two tmux sessions in parallel — each 7–8B model fits comfortably on one 24GB card in fp16.

```bash
# Terminal / tmux pane 1 — GPU 0
CUDA_VISIBLE_DEVICES=0 python tests/run_remote_llm.py --models mistral-7b --precision fp16

# Terminal / tmux pane 2 — GPU 1
CUDA_VISIBLE_DEVICES=1 python tests/run_remote_llm.py --models llama-3-8b --precision fp16
```

### Choice B: Model parallelism (13B+ or fp32)
Span both GPUs with HuggingFace `device_map`:

```bash
python tests/run_remote_llm.py --models llama-2-13b --device-map auto --precision int8
```

### Choice C: GPT-2 / sensitivity profiling (TransformerLens)
Separate from the Phase 10 LLM runner:

```bash
CUDA_VISIBLE_DEVICES=0 python runners/large_model_validator.py \
    --model mistralai/Mistral-7B-v0.1 --samples 50 --precision int8
```

## 5. 24/7 Execution (tmux)

```bash
tmux new -s llm-test
python tests/run_remote_llm.py --models mistral-7b,llama-3-8b
# Ctrl+B, then D to detach
```

## 6. VRAM Guide (3090 24GB)

| Model        | fp16   | int8  | int4   |
|-------------|--------|-------|--------|
| Mistral-7B  | ~15 GB | ~8 GB | ~5.5 GB |
| Llama-3-8B  | ~16 GB | ~9 GB | ~6 GB   |
| Llama-2-13B | OOM*   | ~14 GB | ~9 GB  |

\*Use `--device-map auto` to split 13B across both GPUs.

## 7. Repo Layout (post-migration)

```
code/phases/phase10/     # Lottery ticket pipeline
tests/run_remote_llm.py  # ← primary remote LLM entry point
experiments/phase10/     # JSON results
runners/                 # GPT-2 / TransformerLens workflows
```
