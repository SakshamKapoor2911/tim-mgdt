# 📍 Navigation Guide: Where to Find Everything

**Last Updated**: 2026-03-20

---

## 🎯 I Want To... (Quick Links)

### 👁️ Understand the Project
**Start here:**
1. [README.md](README.md) - 5 min overview of entire project
2. [experiments/phase6/README.md](experiments/phase6/README.md) - 10 min on latest results
3. [experiments/phase6/results/phase6_validation_report.md](experiments/phase6/results/phase6_validation_report.md) - Detailed analysis

**Key Insight**: Layer 10 is elastic (0.98x scaling works). Phase 6 proves reproducibility on 500 samples.

---

### 🔬 Learn About Phase History
**Why different approaches were tried:**

```
Phase 5.1: Hard pruning (remove components)
  ↓ ✗ FAILED (+347-673% PPL explosion)
  → Learned: Transformers are tightly coupled

Phase 5.2: Soft rebalancing (scale parameters)
  ↓ ✓ BREAKTHROUGH (+0.31% PPL)
  → Learned: Model is over-weighted, can be rebalanced

Phase 5.3: Progressive optimization (find optimal scale)
  ↓ ✓ OPTIMAL FOUND (+0.98% PPL at 0.98x scale)
  → Learned: Linear tradeoff between scale and PPL

Phase 6: Large-scale validation (500 samples)
  ↓ ✓ CONFIRMED (-0.11% PPL, reproducible)
  → Learned: 0.98x scaling generalizes to larger datasets
```

**Read**: [Phase 5.1](experiments/phase5_1/README.md) → [5.2](experiments/phase5_2/README.md) → [5.3](experiments/phase5_3/README.md) → [6](experiments/phase6/README.md)

---

### 🚀 Build a Compression System

**For deployment:**
1. Start with: [KL Divergence Proxy](interventions/kl_divergence_proxy/README.md)
   - Fast layer sensitivity ranking (1 second vs 1 hour)
   - Identifies which layers are safe to compress

2. Build: [Quantization Maps](interventions/quantization_maps/README.md)
   - Layer-specific precision (int8/fp16/fp32)
   - 75% model size reduction expected

3. Combine with: [Low-Rank Compression](interventions/low_rank_compression/README.md)
   - Compress activation features
   - Additional 5-10% size reduction

4. Optional: [InAttention](interventions/inattention_conversion/README.md)
   - Replace expensive attention with linear version
   - 4x inference speedup

5. Advanced: [Dynamic Early Exit](interventions/dynamic_early_exit/README.md)
   - Adaptive inference for variable complexity inputs
   - Tunable speed/accuracy tradeoff

**Expected Combined Result**: 75-85% size reduction + 2-4x speedup

---

### 📊 Reproduce Current Results

**To verify Phase 6:**
```bash
cd implementation/
python code/phases/phase6/validation.py --num-samples 500
```

**What you'll get:**
- Baseline PPL: ~51.43
- 0.98x scale PPL: ~51.37
- Delta: -0.11%

**Files to check:**
- [Raw results JSON](experiments/phase6/results/phase6_validation_results.json)
- [Analysis report](experiments/phase6/results/phase6_validation_report.md)
- [Experiment README](experiments/phase6/README.md)

---

### 🔮 Plan Next Steps

**Next in sequence:**
1. **Phase 7** (Alternative Corpora)
   - Test on news, code, scientific text
   - Validate 0.98x generalizes beyond WikiText-2
   - [Plan](experiments/phase7_alternative_corpus/README.md)

2. **Phase 8** (Mistral-7B)
   - Larger model (7B vs 117M parameters)
   - Prove technique scales to production models
   - ⚠️ Blocked: Needs GPU APIs
   - [Plan](experiments/phase8_mistral/README.md)

3. **Phase 9** (Downstream Tasks)
   - NLU, generation, reasoning tasks
   - Prove PPL improvement translates to task quality
   - [Plan](experiments/phase9_downstream/README.md)

---

## 📁 Folder Map

### By Purpose

**For code**:
```
code/
├── phases/              ← Phase implementations (5-6 completed)
│   ├── phase5_1/       ✓ Hard pruning reference
│   ├── phase5_2/       ✓ Soft rebalancing breakthrough
│   ├── phase5_3/       ✓ Progressive scaling
│   └── phase6/         ✓ 500-sample validation
├── metrics/            ← Phase 4 diagnostic proxies
├── models/             ← Model wrappers
└── utils/
```

**For results & docs**:
```
experiments/
├── phase5_1/           ← Phase 5.1 results + README + docs
├── phase5_2/           ← Phase 5.2 results + README + docs
├── phase5_3/           ← Phase 5.3 results + README + docs
├── phase6/             ← Phase 6 results + README + docs
│   ├── README.md       ✓ Latest findings
│   └── results/
│       ├── phase6_validation_results.json      ✓ Raw data
│       └── phase6_validation_report.md         ✓ Analysis
├── phase7_alternative_corpus/     ← TODO with plan
├── phase8_mistral/                ← TODO (blocked: GPU)
└── phase9_downstream/             ← TODO with plan
```

**For interventions** (compression techniques):
```
interventions/
├── inattention_conversion/    🔴 HIGH priority
│   ├── README.md             ✓ Full design doc
│   ├── code/                 (ready for implementation)
│   └── experiments/          (ready for results)
├── quantization_maps/         🔴 HIGH priority (largest ROI)
│   ├── README.md             ✓ Full design doc
│   ├── code/                 (ready for implementation)
│   └── experiments/          (ready for results)
├── kl_divergence_proxy/       🟡 MEDIUM (foundation)
│   ├── README.md             ✓ Full design doc
│   ├── code/                 (ready for implementation)
│   └── experiments/          (ready for results)
├── low_rank_compression/      🟡 MEDIUM
│   ├── README.md             ✓ Full design doc
│   ├── code/                 (ready for implementation)
│   └── experiments/          (ready for results)
└── dynamic_early_exit/        🟢 LOW (specialized)
    ├── README.md             ✓ Full design doc
    ├── code/                 (ready for implementation)
    └── experiments/          (ready for results)
```

---

## 📖 File Types by Phase

### Each Phase Has This Structure

```
experiments/phaseX/
├── README.md              ← START HERE
│                          Contains:
│                          - Objective
│                          - Technical approach
│                          - Key findings
│                          - Success criteria
│                          - Next steps
│
└── results/
    ├── *.json             ← Raw experimental data
    ├── *.md               ← Analysis reports
    └── *.csv              ← Numerical results (if any)
```

**Example**: Phase 6
```
experiments/phase6/
├── README.md              ✓ Comprehensive summary
└── results/
    ├── phase6_validation_results.json      ✓ Scale factor tests
    └── phase6_validation_report.md         ✓ Full analysis
```

---

## 🎓 Learning Path

### For New Team Members

**Day 1: Understand the Problem**
- Read: [README.md](README.md) (5 min)
- Read: [Phase 5.1: Why Hard Pruning Fails](experiments/phase5_1/README.md) (10 min)
- Understand: Layer 10 sensitivity from Phase 4

**Day 2: Understand the Solution**
- Read: [Phase 5.2: Soft Rebalancing](experiments/phase5_2/README.md) (15 min)
- Read: [Phase 5.3: Optimal Scaling](experiments/phase5_3/README.md) (15 min)
- Understand: 0.98x scaling discovery

**Day 3: Understand Validation**
- Read: [Phase 6: 500-Sample Validation](experiments/phase6/README.md) (15 min)
- Read: [Phase 6: Report](experiments/phase6/results/phase6_validation_report.md) (10 min)
- Understand: Reproducibility confirmed

**Day 4: Plan Implementation**
- Read one intervention: [Quantization Maps](interventions/quantization_maps/README.md) (20 min)
- Read foundation: [KL Divergence Proxy](interventions/kl_divergence_proxy/README.md) (15 min)
- Understand: How to build compression system

**Day 5: Execute**
- Start coding [Quantization Maps](interventions/quantization_maps/README.md)
- Use results from [KL Divergence](interventions/kl_divergence_proxy/README.md)
- Implement according to design doc

---

## 🔍 Search Strategy

**Looking for specific information?**

| Looking For | File | Type |
|-------------|------|------|
| How to run Phase 6 | [Phase 6 README](experiments/phase6/README.md) | Code |
| Why Phase 5.1 failed | [Phase 5.1 README](experiments/phase5_1/README.md) | Explanation |
| Current PPL results | [Phase 6 Report](experiments/phase6/results/phase6_validation_report.md) | Data |
| Raw Phase 6 data | [phase6_validation_results.json](experiments/phase6/results/phase6_validation_results.json) | JSON |
| How to build quantization | [Quantization Maps README](interventions/quantization_maps/README.md) | Design Doc |
| Intervention roadmap | [README.md](README.md) section "Intervention Frameworks" | Overview |
| Phase dependencies | [README.md](README.md) section "Phase Roadmap" | Graph |
| Project structure | [README.md](README.md) section "Codebase Organization" | Map |

---

## ⭐ Recommended First Steps

### If you have 15 minutes:
1. Open [README.md](README.md)
2. Scan "Phase Roadmap" section
3. Check [Phase 6 validation results](experiments/phase6/README.md)

### If you have 1 hour:
1. Read [README.md](README.md) thoroughly (15 min)
2. Read [Phase 6 README](experiments/phase6/README.md) (15 min)
3. Read [Phase 6 validation report](experiments/phase6/results/phase6_validation_report.md) (20 min)
4. Skim one intervention: [Quantization Maps](interventions/quantization_maps/README.md) (10 min)

### If you want to implement:
1. Read [Quantization Maps README](interventions/quantization_maps/README.md) (20 min)
2. Read [KL Divergence Proxy README](interventions/kl_divergence_proxy/README.md) (20 min)
3. Use implementation strategy in design docs
4. Execute code template provided

---

## 🚨 Critical Files Alert

**Must-read**:
- ✅ [README.md](README.md) - Project overview
- ✅ [Phase 6 README](experiments/phase6/README.md) - Latest results
- ✅ [Phase 6 Report](experiments/phase6/results/phase6_validation_report.md) - Detailed analysis

**For implementation**:
- ✅ [Quantization Maps](interventions/quantization_maps/README.md) - Highest ROI
- ✅ [KL Divergence Proxy](interventions/kl_divergence_proxy/README.md) - Foundation

**For understanding**:
- ✅ [Phase 5.1](experiments/phase5_1/README.md) - Why hard pruning fails
- ✅ [Phase 5.2](experiments/phase5_2/README.md) - Breakthrough in soft rebalancing

---

## 📞 Getting Help

**Use case** → **Read this** → **File**
- "What's the project?" → Project overview → [README.md](README.md)
- "What were the results?" → Phase 6 summary → [Phase 6 README](experiments/phase6/README.md)
- "Why did they fail?" → Phase history → [Phase 5.1 README](experiments/phase5_1/README.md)
- "How to implement?" → Intervention guide → [Quantization Maps](interventions/quantization_maps/README.md)
- "What's next?" → Roadmap → [README.md](README.md) + [Phase 7](experiments/phase7_alternative_corpus/README.md)

---

**Navigation guide created**: 2026-03-20  
**Status**: ✅ Complete & ready for team use
