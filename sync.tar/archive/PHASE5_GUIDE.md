# Phase 5: Architecture & Usage Guide

## 📊 System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    TIM-MGDT Project Structure               │
└─────────────────────────────────────────────────────────────┘

implementation/
│
├── [PHASE 4 - BASELINE] ─────────────────────
│   ├── run_benchmarks.py (UNCHANGED)
│   ├── metrics/ (ED, Jacobian, nAUDC, Fisher)
│   ├── interventions/ (Layer Ablation)
│   └── experiments/sensitivity_results_*.json
│
├── [PHASE 5 - COMPRESSION] ─────────────────
│
│   ├── advanced_proxies/  (Reusable components)
│   │   ├── head_jacobian.py
│   │   │   └── HeadJacobian.compute_head_scores()
│   │   │       Granular functional leverage per head
│   │   │
│   │   ├── circuit_analyzer.py
│   │   │   └── CircuitAnalyzer.find_winning_tickets()
│   │   │       Stability scoring & ticket identification
│   │   │
│   │   └── pruning_engine.py
│   │       └── PruningEngine.prune_bottom_k_layers()
│   │           Masking-based compression tests
│   │
│   └── phase5/  (Master scripts)
│       ├── run_phase5_compression.py
│       │   └── Standalone Phase 5 (debug mode)
│       │
│       └── run_phase5_with_phase4_integration.py
│           └── Full end-to-end (Phase 4 + 5)
│
└── experiments/
    ├── sensitivity_results_500samples.json      (Phase 4 output)
    ├── phase5_results.json                      (Phase 5 standalone)
    └── phase5_integrated_results.json           (Phase 4 + 5)
```

## 🚀 Three Ways to Run Phase 5

### Mode 1: Standalone (Test Head Granularity)

**Purpose**: Debug the head-level computation without Phase 4 data
**Command**:
```bash
cd implementation
python phase5/run_phase5_compression.py \
    --model gpt2 \
    --head-samples 5 \
    --output-dir experiments
```

**What happens**:
1. Loads model (gpt2)
2. Computes head-level Jacobian (5 calibration texts)
3. Aggregates to layer level
4. Creates placeholder ED/nAUDC (shows how to handle missing data)
5. Computes stability scores
6. Plans pruning (bottom 25%)
7. Verifies model still works with masks
8. Saves results to `experiments/phase5_results.json`

**Output**: Quick diagnostic of head-level leverages
**Time**: 2-3 minutes (local GPU)
**Use case**: Debugging, parameter tuning, testing new models

---

### Mode 2: Full Integration (Use Existing Phase 4 Results)

**Purpose**: Complete pipeline using your 500-sample Phase 4 results
**Command**:
```bash
cd implementation
python phase5/run_phase5_with_phase4_integration.py \
    --phase4-results experiments/sensitivity_results_500samples.json \
    --model gpt2 \
    --head-samples 5 \
    --output-dir experiments
```

**What happens**:
1. Loads Phase 4 results (ED=geometric_ed, Jacobian=causal_jacobian, nAUDC=propagation_naudc)
2. Loads model (gpt2)
3. Computes Phase 5 head-level Jacobian
4. Identifies lottery tickets using Phase 4 + Phase 5 data combined
5. Ranks layers by stability
6. Plans pruning based on full Proxy Triad
7. Saves integrated results

**Output**: Full diagnostic ready for production pruning
**Time**: 3-5 minutes (local GPU)
**Use case**: Production pipeline, paper results, model compression

---

### Mode 3: Compare Models (Cloud Scaling)

**Purpose**: Run same pipeline on larger model to test scalability
**Command**:
```bash
# Same command, different model:
python phase5/run_phase5_with_phase4_integration.py \
    --model mistralai/Mistral-7B-v0.1 \
    --head-samples 10 \
    --output-dir experiments
```

**What happens**: Same as Mode 2, but on Mistral-7B (16GB VRAM)
**Output**: Comparison of Phase 5 diagnostics across model scales
**Use case**: Validating method generalizes

---

## 📈 Data Flow Diagram

```
Phase 4 Results
│
├─ Geometric ED         ──┐
├─ Causal Jacobian      ──┼──> CircuitAnalyzer.find_winning_tickets()
├─ Propagation nAUDC    ──┤      │
├─ Ground Truth Ablation ──┤      ├──> Stability Scores
└─ Correlations (ρ)     ──┘      │
                                  └──> Lottery Ticket Candidates

Phase 5 Computation
│
└─ Head-Level Jacobian ─┐
                        ├──> HeadJacobian.aggregate_to_layer_level()
                        │      │
                        └──────┴──> Comparison View
                                     "Phase 4 vs Phase 5"

Pruning Decision
│
├─ Stability Scores     ──┐
├─ Lottery Tickets      ──┼──> PruningEngine.prune_bottom_k_layers()
└─ Rankings             ──┤      │
                          │      ├──> Pruning Masks
                          │      │    (Applied to model)
                          └──────┘
                                 │
                                 ├──> Verify Inference Works
                                 ├──> Remove Masks (restore)
                                 └──> Save Results
```

## 📋 Results Interpretation

### File: `experiments/phase5_integrated_results.json`

```json
{
  "phase4": {
    "model": "gpt2",                          # Model used
    "num_samples": 500,                       # Phase 4 cal samples
    "correlations": {
      "Ensemble (ED+invJac+invnAUDC)": {
        "spearman_rho": 0.8601,               # ← Your Phase 4 result
        "p_value": 0.00033,
        "is_sign_corrected": false
      }
    }
  },
  "phase5": {
    "head_jacobian_scores": {
      "layer_0_head_0": 12345.6,             # Per-head influence
      "layer_0_head_1": 6789.2,
      ...
    },
    "stability_scores": {
      "layer_0": 1.23e+10,                   # Highest sensitivity
      "layer_1": 5.67e+8,
      "layer_2": 4.32e+8,
      ...
      "layer_11": 9.87e+9                    # Second highest
    },
    "lottery_ticket_candidates": {
      "layer_0": {
        "is_lottery_ticket": true,           # High Jacobian, Low ED
        "jacobian": 27903.37,
        "ed": 351.0,
        "is_high_jacobian": true,
        "is_low_ed": false
      },
      "layer_3": {
        "is_lottery_ticket": false,          # Neither high J nor low ED
        "jacobian": 36533.86,
        "ed": 1.0,                           # Very low ED!
        "is_high_jacobian": true,
        "is_low_ed": true
      }
    },
    "pruning_plan": {
      "pruned_layers": [2, 5, 8],           # Layers to remove
      "k_prune": 3,                          # How many layers
      "pruning_percentage": 25.0             # % of model size
    }
  }
}
```

### How to Read It

1. **Lottery Tickets Found**: `is_lottery_ticket: true` means:
   - Layer has high importance (high Jacobian)
   - Layer is focused/specialized (low ED)
   - Layer likely contains a dense circuit
   
2. **Pruning Plan**: `pruned_layers: [2, 5, 8]` means:
   - These 3 layers have lowest stability
   - If you remove them → 25% model size reduction
   - Next phase: measure accuracy loss when these layers are removed

3. **Expected Outcome**:
   - Remove 3 layers → ✓ if accuracy drops <5%
   - If accuracy stays high → your proxies are validated for production
   - If accuracy drops >10% → these layers are actually important

---

## 🔄 Phase 4 ↔️ Phase 5 Feedback Loop

```
Phase 4 (Baseline)
├─ Run: python run_benchmarks.py (500 samples)
├─ Output: correlation ρ ≈ 0.86
└─ Decision: "Our layer-ranking is solid"
               │
               ↓
        Phase 5 (Granular)
        ├─ Question: "Can we do better per-head?"
        ├─ Run: python phase5/run_phase5_with_phase4_integration.py
        ├─ Output: head granularity, lottery tickets
        └─ Decision: "Identified 3 layers to prune (25%)"
                     │
                     ↓
            Phase 5.1 (Production)
            ├─ Action: Actually prune weights
            ├─ Run: Fine-tune pruned model
            └─ Measurement: accuracy loss from pruning
```

---

## 📖 Key Equations Reference

### Phase 4 (Existing)
- **Effective Dimension (ED)**: Concentrates representation in few dimensions
- **Causal Jacobian**: Gradient effect on logits per layer
- **Propagation (nAUDC)**: Stability under noise perturbation

### Phase 5 (New)
- **Head-Level Jacobian**: 
  ```
  Jacobian_head = ||∂Logits / ∂Head_Output||_2
  ```
  
- **Stability Score**:
  ```
  Stability = (Jacobian / nAUDC) × (1 / ED)
  
  High Stability = {
    ✓ Important (high Jacobian)
    ✓ Stable (low nAUDC)
    ✓ Focused (low ED)
  }
  ```

- **Lottery Ticket Criteria**:
  ```
  is_ticket = (Jacobian > percentile_75) AND (ED < percentile_25)
  ```

---

## ⚡ Performance Expectations

| Model | VRAM | Head Jacobian | Integration | Total Time |
|-------|------|---------------|-------------|-----------|
| gpt2 | 4-6GB | 1 min | 3-5 min | 4-6 min |
| Qwen-0.5B | 3-4GB | 1 min | 3-5 min | 4-6 min |
| Mistral-7B | 16GB | 3 min | 5-10 min | 8-13 min |

---

## 🐛 Common Issues & Solutions

| Issue | Cause | Solution |
|-------|-------|----------|
| "CUDA out of memory" | Too many head samples | Reduce `--head-samples 5` → `--head-samples 3` |
| "No such file" (Phase 4 results) | Wrong path | Check: `ls experiments/sensitivity_results_*.json` |
| "Module not found" | Missing dependency | `pip install transformer-lens` |
| "Very low stability all layers" | Placeholder ED/nAUDC values | Use `--phase4-results` to provide real data |

---

## 📝 Next Actions

✅ **Done (Phase 4)**:
- Layer-level ranking works (ρ = 0.86)

🔄 **Current (Phase 5)**:
- Head-level granularity
- Lottery ticket identification
- Pruning strategy

📅 **Next (Phase 5.1)**:
- Actually prune weights
- Fine-tune compressed model
- Measure inference speedup
- Deploy to edge

---

## 💡 Tips & Tricks

1. **Quick Validation**: Run Mode 1 first to check nothing broke
2. **Parameter Tuning**: Adjust `--head-samples` and `--output-dir` as needed
3. **Comparison Studies**: Run Mode 3 with different models to see patterns
4. **Reproducibility**: All results are deterministic (set seed if needed)
5. **Debugging**: Check `phase5_run.log` or `phase5_integration.log` for details

---

## 🎯 Success Criteria

Phase 5 is successful when:

✓ You can identify which 3-4 layers contribute most to model behavior  
✓ Your head-level granularity adds new insights beyond Phase 4  
✓ Lottery tickets correlate with actual model behavior  
✓ Pruning plan is defensible: "We can improve by X% by removing layers Y"  
✓ Inference speed increases (or at least doesn't decrease much) after pruning

Once these are met, Phase 5.1 (actual compression) is justified.
