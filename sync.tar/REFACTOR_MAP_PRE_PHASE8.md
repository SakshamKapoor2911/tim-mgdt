# Refactor Map Before Phase 8 (Mistral/Llama)

## Goal
Create a clean, publication-ready project structure before adding large-model execution code, so GPT-2 validated work and future 7B/8B work do not get mixed.

## Core Decision
Do not split the entire codebase by model family yet.

Use this pattern instead:
1. Shared core pipeline logic.
2. Model-specific behavior in config or adapter layers.
3. Strict output isolation by phase, model, dataset, and run id.

Reason:
- Most of the current code is shared mechanics (hooks, metrics, ablations, recovery).
- Splitting by model folders too early will duplicate logic and increase maintenance overhead.

## Current State Summary
1. Completed and validated on GPT-2 through Phase 6.
2. Phase 7, 8, and 9 are planned.
3. Phase 8 (Mistral-7B scaling) is documented but still blocked and not implemented as a full dedicated code path.

## Target Structure Principles
1. Organize code by function and phase intent, not by model name.
2. Organize outputs by phase and run metadata, not by ad-hoc filenames.
3. Keep one source of truth for phase status and one canonical report per phase.
4. Archive duplicate historical docs instead of deleting immediately.

## Recommended Directory Strategy
Keep one `experiments/` root, but enforce strict subfolders:

`experiments/<phase>/<model_family>/<dataset>/<run_id>/`

Example:
`experiments/phase8/mistral7b/wikitext2/2026-04-23_2100_seed42/`

Each run folder should contain:
1. `manifest.json` (full run metadata).
2. `metrics.json` (raw machine-readable metrics).
3. `summary.md` (human-readable summary).
4. `run.log` (execution log).
5. Optional plots or artifact files.

Why this is better than a single output directory with naming conventions:
- Stronger separation and provenance.
- Easier reproducibility for paper figures and tables.
- Lower risk of accidental overwrite or cross-phase contamination.

## Standard Run Manifest (Mandatory)
Every run should emit this first:
1. `phase`
2. `model_family` (gpt2, mistral, llama)
3. `model_id` (exact HF model string)
4. `dataset`
5. `sample_count`
6. `seed`
7. `hardware` (GPU model, count, VRAM)
8. `precision` (fp32, fp16, int8, mixed)
9. `commit_hash`
10. `start_time`, `end_time`, `duration_sec`
11. `runner_script`
12. `status`

This is the main defense against mixing GPT-2 and large-model outputs.

## Refactor Plan Status (April 2026)

### Phase A: Freeze and Inventory (100% Complete)
1. [x] Freeze current GPT-2 baseline outputs as reference artifacts.
2. [x] Create `PHASE_STATUS_LEDGER.md`.
3. [x] Identify duplicate docs and move to `archive/`.

### Phase B: Execution Contract (100% Complete)
1. [x] Define manifest schema in `code/utils/manifest.py`.
2. [x] Update runners to require explicit phase/model/dataset/sample config.
3. [x] Remove hidden defaults for paper runs (updated `run_benchmarks.py`).

### Phase C: Output Reorganization (100% Complete)
1. [x] Move existing outputs into phase-scoped folders (`experiments/phaseX/model/dataset/run_id`).
2. [x] Create `PHASE_INDEX.md` files for Phases 2, 5, and 6.
3. [x] Generate legacy manifests for archived GPT-2 runs.

### Phase D: Code Organization Cleanup (90% Complete)
1. [x] Centralize shared code in `code/` submodules.
2. [x] Organize phase-specific logic in `code/phases/`.
3. [x] Add model capability registry in `code/models/registry.py`.
4. [ ] Separate runner entrypoints into `runners/` directory (Scaffolded but needs final migration of `run_benchmarks.py` logic).

### Phase E: Documentation and Bloat Reduction (100% Complete)
1. [x] Update authoritative `README.md` with navigation map and status ledger.
2. [x] Consolidate canonical reports.
3. [x] Move superseded narratives to `archive/`.

## Immediate Next Steps (Post-Refactor)
1. **Runner Specialization:** Migrate the logic from `run_benchmarks.py` into specialized scripts in `runners/` (e.g., `runners/sensitivity_profiler.py`, `runners/compression_pipeline.py`).
2. **Phase 8 Scaffold:** Create the dedicated Mistral/Llama runner using the new `ModelRegistry` to handle 8-bit loading and memory checks automatically.
3. **Promotion Workflow:** Implement a simple script to "promote" a `candidate` run to `reviewed` or `final` by updating its manifest and creating a symlink in the phase root.
4. **Hardware Verification:** Once larger GPU resources are available, run a 10-sample "smoke test" for Mistral-7B using the new hierarchy.

## Definition of Done for Refactor
1. [x] Anyone can locate, for any claim, the exact run folder and manifest.
2. [x] GPT-2 validated outputs and 7B/8B exploratory outputs are impossible to confuse.
3. [x] Entry scripts are clear by phase intent.
4. [x] Documentation is concise, non-duplicative, and evidence-linked.
5. [x] Ready to begin large-model runs without structural debt.

