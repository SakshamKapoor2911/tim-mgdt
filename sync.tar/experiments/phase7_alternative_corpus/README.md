# Phase 7: Alternative Corpus Validation

**Status**: 📋 TODO  
**Planned Date**: TBD  
**Model**: GPT-2 (12 layers, 768 hidden, 117M params)  
**Dataset**: Alternative corpora (news, code, scientific text)  
**Goal**: Verify 0.98x scaling generalizes beyond WikiText-2

---

## Objective

Confirm that the optimal 0.98x Layer 10 scaling discovered on WikiText-2 **generalizes to different text domains** and is not domain-specific.

---

## Proposed Corpora

| Corpus | Samples | Domain | Size | Diversity |
|--------|---------|--------|------|-----------|
| **News/CNN-DailyMail** | 500 | Journalism | ~1K | High |
| **ArXiv Abstracts** | 500 | Scientific | ~1K | High |
| **Code Comments** | 500 | Programming | ~1K | High |
| **Books (Project Gutenberg)** | 500 | Literature | ~2K | High |

---

## Experimental Design

### For Each Corpus:

1. **Baseline Evaluation**
   - Compute baseline PPL on 500 samples
   - Reference point for comparison

2. **Scale Factor Testing**
   - Test: 0.90x, 0.92x, 0.95x, 0.98x, 1.00x
   - Same as Phase 5.3 and Phase 6

3. **Comparison Metrics**
   - PPL delta vs baseline
   - Consistency with WikiText-2 results
   - Domain-specific artifacts

4. **Analysis**
   - Plot PPL vs scale factor for all corpora
   - Test for statistically significant differences
   - Document domain-specific findings

---

## Expected Outcomes

### Scenario A: Scaling Generalizes (Expected)

- ✓ All corpora show similar degradation curves
- ✓ 0.98x scale factor is universally safe
- **Implication**: Ready for downstream applications

### Scenario B: Corpus-Specific Behavior (Alternative)

- ⚠ Different corpora show different sensitivities
- ⚠ News texts more/less sensitive than scientific
- **Implication**: May need corpus-specific tuning

### Scenario C: Improvement Persists (Like Phase 6)

- ✓ Scaling improves PPL in some corpora
- ⚠ Suggests regularization-like effect
- **Implication**: Deeper investigation needed

---

## Success Criteria

✅ **Pass**: PPL delta at ±1.5% for all tested corpora  
⚠️ **Acceptable**: PPL delta at ±3% for some corpora  
❌ **Fail**: PPL delta >±5% in any corpus (signals domain-specific issues)

---

## Files

- **Code**: [code/](code/)
- **Experiments**: [experiments/](experiments/)

---

## Timeline

- **Week 1**: Set up corpus loading and baseline pipelines
- **Week 2**: Run scale factor tests on 2-3 corpora
- **Week 3**: Complete remaining corpora and analysis
- **Week 4**: Generate comparison report

---

## References

- Phase 6: 500-sample validation (predecessor)
- Phase 8: Mistral-7B scaling (successor, uses Phase 7 insights)
