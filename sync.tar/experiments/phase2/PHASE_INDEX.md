# Phase 2 Index: Ground Truth Mapping

## Canonical Runs
- **Model:** GPT-2
- **Dataset:** WikiText-2
- **Run ID:** [baseline_legacy](gpt2/wikitext2/baseline_legacy/)
- **Summary:** Established the ground truth sensitivity ranking for GPT-2 using activation ablation and perplexity delta.

## Key Artifacts
- [Results Comparison](gpt2/wikitext2/baseline_legacy/RESULTS_COMPARISON.md)
- [Sensitivity Results (500 samples)](gpt2/wikitext2/baseline_legacy/sensitivity_results_500samples.json)
