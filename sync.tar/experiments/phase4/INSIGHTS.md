# Phase 4: Diagnostic Triad Proof & Sensitivity Ranking

**Purpose**: This document isolates the core scientific finding from Phase 4, serving as direct empirical evidence for the methodology proposed in `proposal.md`.

## The Core Insight: Triad Validation
The central hypothesis of this project was that we could bypass exhaustive evaluation by using a triad of cheap, forward-pass mechanistic signals (Effective Dimension, Logit Jacobian, and nAUDC) to predict layer sensitivity.

**Empirical Result**: We proved the triad works. 
On a robust 500-sample WikiText-2 calibration set, the Ensemble metric (`ED + invJac + invnAUDC`) achieved a stunning **$\rho = 0.860$** (p=0.00033) correlation against ground-truth Cross-Entropy degradation.

### Breakout Metrics:
1. **Causal (Jacobian)**: $\rho = 0.804$ (p=0.0016)
2. **Propagation (nAUDC)**: $\rho = 0.776$ (p=0.003)
3. **Ensemble (Triad)**: $\rho = 0.860$ (p=0.00033)

## Architectural Impact
Phase 4 successfully ranked **Layer 10** as the 2nd most critical layer in the 12-layer GPT-2 model. This precise ranking setup the crucial elasticity discoveries in Phase 6, proving that diagnostic proxies can safely map the minefield of LLM compression before a single weight is pruned.
