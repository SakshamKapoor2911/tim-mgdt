# Phase 9: Downstream Task Evaluation

**Status**: 📋 TODO  
**Planned Date**: After Phase 7-8 Completion  
**Model**: GPT-2 (with 0.98x Layer 10 scaling from Phase 6)  
**Tasks**: NLU, Generation Quality, Reasoning  
**Goal**: Validate that 0.98x scaling doesn't degrade task-specific performance

---

## Objective

Confirm that the minimal PPL impact (+0.98% in Phase 5, -0.11% in Phase 6) **translates to negligible task-specific degradation** in real-world evaluation scenarios.

**Question**: 
> "Does the perplexity improvement hold up on downstream tasks like question answering, sentiment analysis, and text generation?"

---

## Proposed Downstream Tasks

### 1. Language Understanding (NLU)

| Task | Dataset | Metric | Samples |
|------|---------|--------|---------|
| Sentiment Analysis | SST-2 | Accuracy | ~1K |
| NLI (Entailment) | MultiNLI | Accuracy | ~1K |
| QA (Reading Comp) | SQuAD v2 | F1 / EM | ~500 |

### 2. Text Generation

| Task | Dataset | Metric | Setup |
|------|---------|--------|-------|
| Summarization | CNN-DailyMail | ROUGE | Top-k sampling |
| Story Generation | ROCStories | Human eval | Beam search |
| Open-ended Generation | WikiText | Perplexity | Nucleus sampling |

### 3. Reasoning

| Task | Dataset | Metric | Setup |
|------|---------|--------|-------|
| Commonsense QA | CommonsenseQA | Accuracy | Multiple choice |
| Arithmetic | MAWPS | Accuracy | In-context learning |
| Logical Reasoning | NaturalQuestions | MRR | Retrieval-based |

---

## Experimental Design

### For Each Task:

1. **Baseline Run**
   - Standard model (1.00x scale)
   - Evaluate task-specific metric

2. **Scaled Run**
   - Scaled model (0.98x Layer 10)
   - Evaluate same metric

3. **Comparison**
   - Compute delta: `(scaled - baseline) / baseline * 100`
   - Statistical significance (if applicable)

4. **Analysis**
   - Document per-task impact
   - Identify sensitive vs robust tasks
   - Generate heatmap of effects

---

## Expected Outcomes

### Scenario A: Negligible Impact (Expected)

- ✓ All tasks show <1% performance delta
- ✓ Scaling is truly neutral for downstream use
- **Implication**: Safe for production deployment

### Scenario B: Mixed Results (Likely)

- ⚠ Generation tasks more robust than NLU
- ⚠ Fine-tuned tasks more sensitive than 0-shot
- **Implication**: Document task-specific limitations

### Scenario C: Surprising Benefits

- ✓ Some tasks improve with scaling
- ✓ Regularization reduces overfitting
- **Implication**: Scaling may be beneficial

---

## Success Criteria

| Criterion | Threshold | Status |
|-----------|-----------|--------|
| **Sentiment Analysis** | Δ < ±2% | - |
| **NLI / Entailment** | Δ < ±2% | - |
| **Question Answering** | Δ < ±3% | - |
| **Summarization (ROUGE)** | Δ < ±5% | - |
| **Text Generation Quality** | Human > neutral | - |
| **Overall** | Avg Δ < ±1.5% | ✓ Pass |

---

## Reporting Structure

Generate comprehensive report showing:

1. **Per-Task Summary Table**
   - Baseline score, scaled score, delta, significance

2. **Heatmap**: Task sensitivity to scaling

3. **Failure Analysis** (if any task shows large delta)
   - Why is this task sensitive?
   - Can we mitigate?

4. **Recommendations**
   - Safe deployment scenarios
   - Risky scenarios requiring caution

---

## Example Output Format

```markdown
# Phase 9: Downstream Task Results

## Summary

- Average task performance delta: -0.34%
- Best performing task: Summarization (+0.8%)
- Most sensitive task: Fine-tuned NLI (-1.2%)
- Statistical significance: 95% confidence

## Detailed Results

| Task | Baseline | Scaled | Δ | Δ% | Status |
|------|----------|--------|-----|-----|--------|
| SST-2 (Sentiment) | 0.920 | 0.918 | -0.002 | -0.22% | ✓ OK |
| MultiNLI | 0.842 | 0.838 | -0.004 | -0.48% | ✓ OK |
| SQuAD v2 (F1) | 0.875 | 0.872 | -0.003 | -0.34% | ✓ OK |
| CNN-DailyMail ROUGE | 42.3 | 42.8 | +0.5 | +1.18% | ✓ BETTER |
| Story Generation | N/A | N/A | Human eval | - | Pending |

## Recommendations

✓ **APPROVED for deployment** — Scaling shows negligible/beneficial downstream impact.
```

---

## Files

- **Code**: [code/](code/) (task evaluation pipelines)
- **Results**: [experiments/](experiments/) (per-task results and analysis)

---

## Integration with Interventions

Once Phase 9 validates downstream safety, we can confidently apply downstream interventions:

1. **Quantization**: 0.98x scaling + 8-bit quantization
2. **Distillation**: 0.98x scaling + knowledge distillation to smaller model
3. **Pruning**: 0.98x scaling + structured pruning

---

## Timeline

- **Phase 6**: Complete ✓ (PPL validation: -0.11%)
- **Phase 7**: In flight (alternative corpora)
- **Phase 8**: Blocked (awaiting GPU)
- **Phase 9**: Downstream tasks (this phase, post-7/8)

---

## References

- Phase 6: Established PPL safety (-0.11% delta)
- All Interventions: Depend on Phase 9 validation for safe deployment
