# Phase 11: Advanced Subnetwork & Compression Optimizations

This document presents the theoretical foundations, implementation strategies, and academic references for the advanced compression and mechanical interpretability techniques introduced in Phase 11.

---

## 📊 Optimization Matrix: Phase 10 vs. Phase 11

The following table summarizes the key improvements of Phase 11 over the baseline Phase 10 pruning setup:

| Dimension | Phase 10 (Baseline) | Phase 11 (Advanced Upgrade) |
| :--- | :--- | :--- |
| **Pruning Strategy** | **Layer Pruning:** Drops entire transformer blocks (e.g., 30% of layers) based on global attention importance stats. | **Structured Head & GQA-Aware Attention Pruning:** Prunes individual attention heads or key-value head groups (Grouped-Query Attention) rather than dropping entire transformer layers. |
| **Winning Ticket Search** | **One-Shot Layer Ranking:** Ranks layers once based on attention variance, then generates a single static mask (subnetwork). | **Iterative Magnitude Pruning (IMP) with Calibration:** Multi-step pruning loop where components are iteratively masked, followed by short calibration forward passes to adjust attention distributions. |
| **MechInterp Metric** | **Attention Variance:** Uses simple attention maps (`output_attentions=True`) and ranks layer standard deviations. | **Mechanical Interpretability with Activation Patching:** Replaces passive attention statistics with causal activation patching to measure how critical specific subnetworks are to output generation. |
| **Calibration / Healing** | **Zero Fine-Tuning:** Prunes the layers and runs evaluation instantly (expecting minor quality degradation). | **Weight/Bias Healing (Calibration):** Performs linear feature-alignment scaling on the output representations of surviving layers to adapt for missing features and recover perplexity without expensive backpropagation. |

---

## 🧠 Detailed Paradigm Explanations

### 1. Structured Head & GQA-Aware Attention Pruning
Instead of dropping entire layers, Phase 11 enables structural pruning of individual multi-head attention (MHA) or Grouped-Query Attention (GQA) heads. GQA, as used in **Llama-3-8B** and **Mistral-7B**, pairs multiple Query heads with a single Key-Value head group. Pruning individual Q heads or whole KV-groups reduces model memory usage and increases arithmetic throughput during generation.
* **Mechanism:** Computes the contribution of each attention head group, masking out the lowest-scoring heads.

### 2. Iterative Magnitude Pruning (IMP)
Drawn from the **Lottery Ticket Hypothesis**, IMP shows that pruning in a single shot can cause catastrophic performance degradation at high sparsity levels. 
* **Mechanism:** We prune the model incrementally (e.g., 10% sparsity per step). At each step, a minor calibration pass allows the remaining attention weights to self-adjust, finding winning subnetworks that perform optimally at much higher sparsity levels (e.g., up to 50%).

### 3. Causal Activation Patching
Passive metrics like attention variance only correlate with importance. Causal activation patching actively measures utility.
* **Mechanism:** We run a clean prompt forward pass, cache the activations, and run a corrupted prompt pass. We surgically "patch" the activations of a specific head/layer from the clean pass into the corrupted pass. If performance is restored, that subnetwork causally carries the task-critical representation.

### 4. Weight/Bias Healing (Calibration)
When a layer or head is pruned, the downstream layers receive shifted input distributions. Rather than running slow backpropagation, **Activation Healing** computes the covariance of activations before and after pruning on a tiny calibration batch, solving a linear least-squares problem to scale the output weights of surviving layers to align them with the original activation space.

---

## 📚 Academic References & Citations

1. **The Lottery Ticket Hypothesis: Finding Sparse, Trainable Neural Networks**
   * *Citation:* Frankle, J., & Carbin, M. (2018). *The Lottery Ticket Hypothesis: Finding Sparse, Trainable Neural Networks*. arXiv preprint arXiv:1803.03635.
   * *Relevance:* Foundations of Iterative Magnitude Pruning (IMP) and finding subnetwork structures.

2. **GQA: Training Generalized Grouped-Query Attention for Ultra-Fast Multi-Decoders**
   * *Citation:* Ainslie, J., et al. (2023). *GQA: Training Generalized Grouped-Query Attention for Ultra-Fast Multi-Decoders*. arXiv preprint arXiv:2305.13245.
   * *Relevance:* Structural guidelines for KV-head grouping and speedups on modern LLMs like Llama-3 and Mistral.

3. **Causal Mediation Analysis for Interpreting Neural Networks**
   * *Citation:* Vig, J., et al. (2020). *Investigating Gender Bias in Language Models Using Causal Mediation Analysis*. NeurIPS.
   * *Relevance:* Theoretical basis for Causal Activation Patching in Mechanical Interpretability.

4. **Layer Pruning & Activation Healing for LLM Compression**
   * *Citation:* Gromov, A., et al. (2024). *The Unreasonable Ineffectiveness of the Deeper Layers: Pruning LLMs and Healing*. arXiv preprint arXiv:2403.17887.
   * *Relevance:* Theoretical and empirical backing for weight/bias healing calibration post-pruning.
