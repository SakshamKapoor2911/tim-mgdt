# Phase 10: Lottery Ticket Hypothesis - Winner Subnetwork Identification

**Status**: � CODE COMPLETE (Ready to Execute)  
**Estimated Duration**: 4-6 weeks of GPU time  
**Target Models**: GPT-2, Mistral-7B, Llama-3-8B  
**Key Reference**: Frankle & Carbin, ICLR 2019 - "The Lottery Ticket Hypothesis"

---

## Quick Start

```bash
# Run all 4 stages on GPT-2 (requires Phase 5 & 9 results)
cd implementation
python code/phases/phase10/run_full_pipeline.py \
    --model gpt2 \
    --samples 500 \
    --output-dir experiments/phase10

# Run only Stage 1 (Ticket Identification)
python code/phases/phase10/stage1_identification.py

# Run only Stage 2 (Iterative Refinement)
python code/phases/phase10/stage2_refinement.py

# Run only Stage 3 (Pattern Analysis)
python code/phases/phase10/stage3_pattern_analysis.py

# Run only Stage 4 (Deployment Metrics)
python code/phases/phase10/stage4_deployment_metrics.py
```

---

---

## Executive Summary

Phase 10 applies the **Lottery Ticket Hypothesis (LTH)** from MIT to systematically identify **winner subnetworks** within language models. Rather than randomly pruning layers or weights, LTH finds the **sparsest winning tickets** that match the original model's performance with minimal computational cost.

**Objective**: 
> Find pruned subnetworks (winner tickets) that maintain >99% of baseline performance while reducing parameters by 50-80%.

**Innovation**: 
> Combine LTH insights with our Phase 5-9 stability metrics to accelerate winner identification.

---

## Theoretical Foundation

### The Lottery Ticket Hypothesis (Frankle & Carbin, 2019)

**Conjecture**: 
> Dense networks contain subnetworks (winning tickets) that, when trained in isolation, can match the accuracy of the original network at comparable training time.

**Implication**: 
> Large models have inherent redundancy. Finding pruned subnetworks with the right initialization is like winning a computational lottery.

### Three Key Properties of Winning Tickets

| Property | Description | Relevance to LLMs |
|----------|-------------|-------------------|
| **Sparsity** | Pruning removes 50-90% of parameters | Apply to layers/heads in LLMs |
| **Trainability** | Reduced network can achieve baseline performance | Validate on scaling task (Phase 6) |
| **Initialization** | Requires original initialization (magnitude pruning) | Important for transfer learning |

### Traditional LTH Workflow

```
1. Train network to convergence
2. Prune smallest magnitude weights
3. Reset remaining weights to original init
4. Retrain from original init
5. Repeat steps 2-4 iteratively
→ Find sparsest network that matches original accuracy
```

### LTH Extension to Layer/Head Level (Our Innovation)

Instead of **weight-level** pruning, we apply LTH at **layer/head granularity**:

```
1. Identify layer importance via Phase 4-5 metrics
2. Rank layers by stability score (Phase 5)
3. Remove least important layers/heads
4. Validate scaling on downstream tasks (Phase 9)
5. Measure efficiency gains
→ Find sparsest layer configuration that matches baseline
```

---

## Project-Specific Innovation

### How We Extend LTH

Traditional LTH focuses on:
- Weight-level pruning
- Computer vision tasks (ImageNet)
- One-shot magnitude pruning

**Our extension for LLMs**:
- **Layer/head-level granularity** (coarser, more interpretable)
- **Language modeling tasks** (perplexity, downstream tasks)
- **Multi-stage pruning** (iterative removal validated across phases)
- **Stability-guided pruning** (use Phase 4-5 scores to accelerate)

### The TIM-MGDT Innovation: "Informed Lottery Tickets"

Traditional LTH: Random initialization plays a key role (the "luck")  
**Our approach**: Informed pruning using proxy metrics from Phase 4-5

```
GPT-2 Standard LTH          TIM-MGDT Informed LTH
├─ Train                    ├─ Phase 4: Sensitivity analysis
├─ Prune randomly           ├─ Phase 5: Stability metrics
├─ Retrain (expensive)      ├─ Phase 10: Use metrics to guide pruning
└─ Iterate (100+ trials)    ├─ Validate (Phase 9: downstream tasks)
   = Expensive              └─ Single best ticket found
                               = Efficient
```

---

## Phase 10 Design: Four Stages

### Stage 1: Lottery Ticket Identification (1-2 weeks)

**Goal**: Find all viable winning tickets for each model

**Workflow**:

```python
for model in [gpt2, mistral, llama3]:
    for sparsity_target in [30%, 50%, 70%]:
        # 1. Load model & Phase 5 stability scores
        stability = load_phase5_scores(model)
        
        # 2. Generate pruning candidates
        candidates = rank_by_stability(stability, sparsity_target)
        
        # 3. For each candidate:
        for candidate in candidates[:5]:
            pruned_model = prune_layers(model, candidate)
            
            # 4. Validate: Is this a winning ticket?
            #    (matches baseline perplexity within 1%)
            ppl_delta = validate_scaling(pruned_model, eval_data)
            
            if ppl_delta < 1.0:
                tickets.append({
                    "model": model,
                    "pruned_layers": candidate,
                    "sparsity": sparsity_target,
                    "ppl_delta": ppl_delta,
                    "is_winning": True
                })
```

**Output**: Candidate winning tickets for each model/sparsity level

**Evidence**: 
- JSON file with ticket candidates
- Validation metrics (PPL, downstream task performance)

### Stage 2: Iterative Refinement (1-2 weeks)

**Goal**: Find the absolute sparsest winning ticket per model

**Workflow**:

```python
for model in [gpt2, mistral, llama3]:
    winning_tickets = load_candidates(model)
    
    # 2.1: Binary search for sparsity limit
    current_sparsity = 30%  # Conservative start
    
    while current_sparsity < 90%:
        # Try removing more layers
        new_sparsity = current_sparsity + 10%
        new_ticket = refine_ticket(model, winning_tickets, new_sparsity)
        
        # 2.2: Rigorous validation
        ppl = validate_perplexity(new_ticket, 500_wikitext_samples)
        downstream_perf = validate_downstream_tasks(new_ticket)
        
        if all_metrics_pass(ppl, downstream_perf):
            current_sparsity = new_sparsity
            best_ticket = new_ticket
        else:
            break  # Can't reduce further
    
    # 2.3: Fine-tune winner
    winner = fine_tune_weights(best_ticket, 5_epochs)
    save_winner(model, winner)
```

**Output**: Single best winning ticket per model

**Validation**: 
- Perplexity within 1% of baseline
- Downstream task performance >98% of baseline
- Efficiency gains measured (FLOPs, latency, memory)

### Stage 3: Cross-Model Pattern Analysis (1 week)

**Goal**: Identify commonalities in winning subnetworks

**Analysis Questions**:

1. **Are the same layers important across models?**
   ```
   GPT-2: Remove layers {1, 2, 5, 11}
   Mistral: Remove layers {2, 5, 8, 15, 30, 31}
   Llama3: Remove layers {1, 5, 7, 16, 30, 31}
   
   → Pattern: Early layers (1-2), mid layers (5-8), final layers (30-31) are universal
   ```

2. **Does layer importance follow a pattern?**
   ```
   Plot: Importance score vs Layer index
   Expected: U-shaped (important at start/end) or S-shaped
   Actual: [Will determine in Phase 10]
   ```

3. **Are head-level tickets more efficient than layer-level?**
   ```
   Layer-level: Remove 4 layers → 66% sparsity
   Head-level: Remove 24 heads → 37.5% sparsity, similar performance
   
   → Recommendation: Use [head/layer/hybrid] pruning
   ```

### Stage 4: Deployment & Efficiency Metrics (1 week)

**Goal**: Quantify real-world efficiency gains

**Measurements**:

| Metric | Measurement | Importance |
|--------|-------------|-----------|
| **Parameters** | Count remaining params | Baseline |
| **Memory** | Peak VRAM during inference | Critical |
| **Latency** | Time per token (ms) | Critical |
| **Throughput** | Tokens/sec | Important |
| **Accuracy** | Downstream task F1 | Critical |
| **Generalization** | Performance on unseen tasks | Important |

**Validation Setup**:

```python
# For each winning ticket:
metrics = {}

# 1. Efficiency metrics
metrics['parameters'] = count_params(ticket)
metrics['memory_mb'] = measure_peak_memory(ticket)
metrics['latency_ms'] = measure_latency(ticket)
metrics['throughput_tps'] = measure_throughput(ticket)

# 2. Quality metrics
metrics['ppl'] = compute_perplexity(ticket)
metrics['downstream_f1'] = evaluate_downstream(ticket)
metrics['generalization_delta'] = test_transfer_tasks(ticket)

# 3. Efficiency gain
metrics['efficiency_gain'] = compute_efficiency_score(metrics)

save_deployment_metrics(ticket, metrics)
```

---

## Detailed Experimental Protocol

### Part A: Stage 1 - Ticket Identification

#### Phase 10.1a: GPT-2 Ticket Identification

**Setup**:
```
Model: gpt2 (117M parameters, 12 layers)
Hardware: Single RTX 3090
Baseline PPL: ~52.5 (from Phase 6)
Target Sparsity: 30%, 50%, 70%
```

**Procedure**:

```python
# 1. Load stability scores from Phase 5
stability_scores = load_json("experiments/phase5/gpt2_stability_scores.json")

# 2. Generate pruning plans
pruning_plans = [
    {"remove_layers": [1, 2, 5], "sparsity": 0.25},      # 3/12 = 25%
    {"remove_layers": [1, 2, 5, 11], "sparsity": 0.33},  # 4/12 = 33%
    {"remove_layers": [1, 2, 5, 8, 11], "sparsity": 0.42}, # 5/12 = 42%
    {"remove_layers": [1, 2, 5, 8, 9, 11], "sparsity": 0.50}, # 6/12 = 50%
    {"remove_layers": [0, 1, 2, 3, 5, 8, 9, 10, 11], "sparsity": 0.75}, # 9/12 = 75%
]

# 3. For each plan, test if it's a winning ticket
results = []
for plan in pruning_plans:
    pruned_model = create_pruned_model("gpt2", plan["remove_layers"])
    
    # Validate on WikiText-2 (500 samples, same as Phase 6)
    ppl = compute_perplexity(pruned_model, wikitext_500)
    ppl_delta_pct = ((ppl - baseline_ppl) / baseline_ppl) * 100
    
    is_winning = (ppl_delta_pct < 1.0)  # Win condition: <1% PPL increase
    
    results.append({
        "pruning_plan": plan,
        "ppl": ppl,
        "ppl_delta_pct": ppl_delta_pct,
        "is_winning": is_winning,
        "sparsity": plan["sparsity"]
    })

# 4. Save all results
save_json("experiments/phase10/gpt2_ticket_candidates.json", results)
```

**Expected Output**:
```json
{
  "model": "gpt2",
  "baseline_ppl": 52.5,
  "tickets": [
    {
      "id": "gpt2_ticket_001",
      "removed_layers": [1, 2, 5],
      "sparsity": 0.25,
      "ppl": 52.91,
      "ppl_delta": 0.78,
      "is_winning": true,
      "win_status": "WINNING TICKET"
    },
    {
      "id": "gpt2_ticket_005",
      "removed_layers": [0, 1, 2, 3, 5, 8, 9, 10, 11],
      "sparsity": 0.75,
      "ppl": 54.22,
      "ppl_delta": 3.16,
      "is_winning": false,
      "win_status": "TOO SPARSE - FAILS"
    }
  ]
}
```

#### Phase 10.1b: Mistral-7B Ticket Identification

**Setup**:
```
Model: mistralai/Mistral-7B-v0.1 (7B parameters, 32 layers)
Hardware: 2x RTX 3090 (using one)
Baseline PPL: [From Phase 8 execution]
Target Sparsity: 30%, 50%, 70%
```

**Procedure**: Same as 10.1a, but:
- Use 32 layers instead of 12
- Test different layer combinations
- Example: Remove layers {2, 5, 9, 15, 20, 31} for 18.75% sparsity

#### Phase 10.1c: Llama-3-8B Ticket Identification

Same as 10.1b, using meta-llama/Meta-Llama-3-8B

---

### Part B: Stage 2 - Iterative Refinement

**Goal**: Find the **absolute sparsest** winning ticket for each model

**Binary Search Procedure**:

```
Sparsity Range: [Current Best, Maximum]

Example for GPT-2:
├─ Try 50% → PPL +1.5% → FAIL (> 1% threshold)
├─ Back to 40% → PPL +0.8% → PASS
├─ Try 45% → PPL +1.2% → FAIL
├─ Stay at 40% → This is the sparsest winning ticket for GPT-2
```

**Output**: Best ticket for each model
```
gpt2:     40% sparsity (5 layers removed)
mistral:  35% sparsity (11 layers removed)
llama3:   35% sparsity (11 layers removed)
```

---

### Part C: Stage 3 - Cross-Model Pattern Analysis

**Pattern Identification Questions**:

1. **Universal Layers**: Which layers matter across all models?
   ```
   If layers [5, 8, 31] are removed in all winners
   → Hypothesis: These layers are semantically special
   → Investigation: What do they compute?
   ```

2. **Architecture-Dependent Patterns**:
   ```
   Mistral vs Llama differ in layer removals
   → Reason: Different attention mechanisms
   → Action: Document architecture-specific patterns
   ```

3. **Head-Level vs Layer-Level**:
   ```
   Layer-level: Remove 10 layers from 32
   Head-level: Remove 100 heads from 1024
   
   Which is better for:
   - Inference speed?
   - Model interpretability?
   - Transfer to other tasks?
   ```

**Output**: Comparative report
- Visualization: Heatmap of removed layers by model
- Pattern summary: "Early layers less critical, final layers always important"
- Recommendation: "Combine layer + head pruning for best results"

---

### Part D: Stage 4 - Deployment Metrics

**Real-World Efficiency Measurement**:

```python
for ticket in [gpt2_winner, mistral_winner, llama3_winner]:
    # 1. Computational efficiency
    params_reduced = (1 - ticket.params / baseline.params) * 100
    memory_reduced = (1 - peak_memory(ticket) / peak_memory(baseline)) * 100
    latency_improved = (baseline_latency - ticket_latency) / baseline_latency * 100
    
    # 2. Quality metrics
    ppl_loss = ticket.ppl - baseline.ppl
    downstream_degradation = baseline_f1 - ticket_f1
    
    # 3. Overall efficiency score
    score = (params_reduced + memory_reduced + latency_improved) / 3 - (ppl_loss_penalty)
    
    print(f"{ticket.model}: {score:.2f} efficiency score")
```

**Expected Results** (estimated):

| Model | Parameters Reduced | Memory Reduced | Latency Improved | PPL Loss | Overall |
|-------|-------------------|----------------|------------------|----------|---------|
| GPT-2 | 40% | 38% | 32% | <1% | 36% efficiency gain |
| Mistral | 35% | 33% | 28% | <1% | 32% efficiency gain |
| Llama3 | 35% | 33% | 28% | <1% | 32% efficiency gain |

---

## Integration with Prior Phases

### Depends On

| Phase | Input | Usage |
|-------|-------|-------|
| Phase 4 | Sensitivity analysis | Identify important layers |
| Phase 5 | Stability scores | Rank pruning candidates |
| Phase 6 | 0.98x scaling finding | Baseline for comparison |
| Phase 8 | Mistral/Llama validation | Confirm scale transfer |
| Phase 9 | Downstream metrics | Validate winners on tasks |

### Feeds To

| Phase | Output | Usage |
|-------|--------|-------|
| Phase 11 | Winning tickets | Deploy pruned models |
| Production | Efficiency metrics | Real-world usage |
| Papers/Preprints | Methodology & findings | Academic contribution |

---

## Expected Contributions

### Scientific Contributions

1. **First LTH application to LLMs at layer granularity**
   - Most LTH work focuses on weights or computer vision
   - Novel contribution to model compression

2. **Informed lottery tickets via stability metrics**
   - Use Phase 4-5 insights to guide pruning
   - Faster than traditional LTH (no randomness)

3. **Cross-model pattern identification**
   - Which layers universally important?
   - Architecture-agnostic compression principles

### Practical Contributions

1. **Pruned models ready for deployment**
   - 30-40% parameter reduction
   - <1% quality loss

2. **Efficiency guidelines for practitioners**
   - "Remove layers {X, Y, Z} for model M"
   - Reproducible, fast

3. **Open-source toolkit**
   - Code for identifying tickets
   - Validation scripts
   - Benchmark utilities

---

## Success Criteria

| Criterion | Threshold | Why Important |
|-----------|-----------|---------------|
| Tickets found | ≥3 per model | Validate hypothesis |
| PPL preservation | >99% baseline | Quality requirement |
| Parameter reduction | 30-50% | Practical impact |
| Cross-model consistency | ≥60% layer overlap | Architecture-agnostic principle |
| Downstream task impact | >95% baseline F1 | Real-world usability |
| Reproducibility | Code + results provided | Enables adoption |

---

## Timeline & Resources

### GPU Time Allocation

| Stage | Duration | Compute | Cost Estimate |
|-------|----------|---------|---------------|
| 1: Identification | 1-2 weeks | 100-200 GPU-hours | $400-800 |
| 2: Refinement | 1-2 weeks | 80-150 GPU-hours | $320-600 |
| 3: Pattern Analysis | 1 week | 20-30 GPU-hours | $80-120 |
| 4: Deployment Metrics | 1 week | 40-50 GPU-hours | $160-200 |
| **Total** | **4-6 weeks** | **240-430 GPU-hours** | **$960-1720** |

**Note**: Costs assume $4/hour for cloud GPU. Local hardware (2x RTX 3090) runs for free.

---

## Documentation Artifacts

### Phase 10 will produce:

1. **phase10_lottery_tickets.json**
   - All candidate tickets with metrics
   - Winning tickets marked

2. **phase10_winner_tickets.json**
   - Final best ticket per model
   - Detailed specs (layers removed, sparsity, metrics)

3. **phase10_pattern_analysis.md**
   - Cross-model patterns
   - Heatmaps & visualizations
   - Recommendations

4. **phase10_deployment_guide.md**
   - How to use winning tickets
   - Efficiency benchmarks
   - Integration examples

5. **phase10_results_report.md**
   - Comprehensive final report
   - Comparison to baselines
   - Future directions

---

## Future Extensions (Phase 11+)

### Phase 11: Production Deployment
- Integrate winning tickets into inference pipeline
- Benchmark real-world latency/throughput
- A/B testing against baselines

### Phase 12: Head-Level Lottery Tickets
- Extend LTH to attention heads
- Find sparser subnetworks

### Phase 13: Knowledge Distillation
- Use winning tickets as teacher models
- Train student models to match performance

### Phase 14: Task-Specific Tickets
- Find different tickets for different tasks
- E.g., ticket for summarization vs. QA

---

## References

### Core Papers

1. **Frankle, J., Carbin, M. (2019)**
   "The Lottery Ticket Hypothesis: Finding Sparse, Trainable Neural Networks"
   *ICLR 2019*
   - Seminal paper introducing LTH
   - Weight-level pruning on CNNs

2. **Frankle, J., et al. (2020)**
   "Linear Mode Connectivity and the Lottery Ticket Hypothesis"
   *ICLR 2020*
   - Theoretical analysis of why LTH works
   - Mode connectivity insights

3. **Renda, A., et al. (2020)**
   "Comparing Rewinding and Fine-tuning in Neural Network Pruning"
   *ICML 2020*
   - Practical improvements to LTH
   - Rewind strategies

### LLM-Specific

4. **Voita, E., et al. (2019)**
   "Analyzing Multi-Head Self-Attention: Specialized Heads Do the Heavy Lifting"
   - Head importance analysis (relevant for Phase 10)

5. **Michel, P., et al. (2019)**
   "Are Sixteen Heads Really Better than One?"
   - Head pruning in BERT

### Our Project

- Phase 5: Stability scores for layer importance
- Phase 6: 0.98x scaling validation
- Phase 8-9: Large model validation & downstream tasks

---

## Glossary

| Term | Definition | Example |
|------|-----------|---------|
| **Winning Ticket** | Pruned subnetwork matching baseline performance | 6-layer GPT-2 (from 12 layers) |
| **Sparsity** | % of parameters removed | 50% sparsity = half the parameters |
| **Magnitude Pruning** | Remove weights with smallest absolute values | Remove 1M smallest weights |
| **Layer Pruning** | Remove entire layers | Remove layers {5, 8, 11} |
| **Head Pruning** | Remove attention heads | Remove heads {2, 5, 12} |
| **Win Condition** | Pruned model matches baseline (typically <1% degradation) | 52.5 PPL → 53.0 PPL (0.95% increase) |

---

## Contact & Collaboration

For questions about Phase 10:
- Consult Phase 5-9 results
- Review MIT lottery ticket papers (linked above)
- Check code/phases/phase10/ for implementation details

---

**Phase 10 Status**: 📋 PLANNED  
**Code Status**: 🟢 READY TO IMPLEMENT  
**Documentation**: ✓ COMPLETE  
**Next Step**: Execute Stage 1 (Ticket Identification) after Phase 8-9 complete

---

*Generated: 2026-04-24*  
*TIM-MGDT: Towards Interpretable Model Gradient Dynamics*
