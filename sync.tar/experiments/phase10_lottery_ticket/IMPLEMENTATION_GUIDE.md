# Phase 10: Technical Implementation Guide

## Overview

This guide provides step-by-step instructions for implementing Phase 10: Lottery Ticket Hypothesis (LTH) winner identification.

**STATUS**: ✅ **CODE COMPLETE** - All implementation is done! See [code/phases/phase10/](../../code/phases/phase10/) for the actual implementation.

---

## Quick Links to Actual Code

Instead of templates below, use the production-ready code:

| Stage | File | Lines | Status |
|-------|------|-------|--------|
| **1** | [stage1_identification.py](../../code/phases/phase10/stage1_identification.py) | 600 | ✅ Complete |
| **2** | [stage2_refinement.py](../../code/phases/phase10/stage2_refinement.py) | 350 | ✅ Complete |
| **3** | [stage3_pattern_analysis.py](../../code/phases/phase10/stage3_pattern_analysis.py) | 350 | ✅ Complete |
| **4** | [stage4_deployment_metrics.py](../../code/phases/phase10/stage4_deployment_metrics.py) | 450 | ✅ Complete |
| **Utils** | [utils.py](../../code/phases/phase10/utils.py) | 150 | ✅ Complete |
| **Pipeline** | [run_full_pipeline.py](../../code/phases/phase10/run_full_pipeline.py) | 300 | ✅ Complete |

**Run the full pipeline:**
```bash
cd implementation
python code/phases/phase10/run_full_pipeline.py --model gpt2 --samples 500
```

---

## Code Architecture Overview

```
Phase 10 Pipeline
=================

Input: Phase 5-9 Results
  ├─ Phase 5: Stability scores
  ├─ Phase 6: Optimal scaling (0.98x)
  ├─ Phase 8: Large model validation
  └─ Phase 9: Downstream task metrics

Stage 1: Ticket Identification
  ├─ Load model + stability scores
  ├─ Generate pruning candidates
  ├─ Apply pruning (layer removal)
  └─ Validate: Is it a winning ticket?

Stage 2: Iterative Refinement
  ├─ Binary search for sparsity limit
  ├─ Refine pruning strategy
  └─ Find absolute sparsest winner

Stage 3: Pattern Analysis
  ├─ Identify universal layers
  ├─ Cross-model comparison
  └─ Generate recommendations

Stage 4: Deployment Metrics
  ├─ Measure inference latency
  ├─ Measure memory usage
  └─ Quantify efficiency gains

Output: Winning Tickets + Deployment Guide
  ├─ phase10_gpt2_winner.json
  ├─ phase10_mistral_winner.json
  ├─ phase10_llama3_winner.json
  └─ phase10_deployment_guide.md
```

---

## Reference Code Examples

The sections below show example code patterns. For complete, production-ready implementations, see the files linked above.

---

---

## Stage 1: Ticket Identification

### Step 1.1: Data Preparation

```python
"""step_1_1_prepare_data.py - Prepare evaluation data"""

import json
from datasets import load_dataset
from transformers import AutoTokenizer

def prepare_wikitext_2():
    """Load and cache WikiText-2 for reproducibility."""
    dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="test")
    
    # Use same 500 samples as Phase 6
    samples = []
    for i in range(min(500, len(dataset))):
        text = dataset[i]['text'].strip()
        if text:
            samples.append(text)
    
    return samples[:500]

def prepare_tokens(texts, tokenizer, max_length=512):
    """Tokenize for efficient processing."""
    return [
        tokenizer.encode(text, truncation=True, max_length=max_length)
        for text in texts
    ]

# Main
if __name__ == "__main__":
    samples = prepare_wikitext_2()
    save_json("data/wikitext2_500_samples.json", samples)
    print(f"Prepared {len(samples)} samples")
```

### Step 1.2: Load Stability Scores

```python
"""step_1_2_load_stability.py - Load Phase 5 stability metrics"""

import json
from typing import Dict

def load_phase5_stability(model: str) -> Dict[str, float]:
    """Load stability scores from Phase 5."""
    # Phase 5 output structure:
    # {
    #   "layer_0": 1.234,
    #   "layer_1": 0.567,
    #   ...
    # }
    
    path = f"experiments/phase5/{model}/stability_scores.json"
    with open(path) as f:
        return json.load(f)

def rank_layers_by_importance(stability: Dict[str, float], ascending=True):
    """Rank layers from least to most important.
    
    For pruning, we want to remove least important (ascending=True).
    """
    sorted_layers = sorted(
        stability.items(),
        key=lambda x: x[1],
        reverse=not ascending
    )
    return [layer for layer, score in sorted_layers]

# Example: Get least important layers to prune
stability = load_phase5_stability("gpt2")
pruning_candidates = rank_layers_by_importance(stability, ascending=True)[:5]
print(f"Top 5 candidates for removal: {pruning_candidates}")
```

### Step 1.3: Generate Pruning Plans

```python
"""step_1_3_generate_pruning_plans.py - Create candidate pruning configurations"""

from itertools import combinations
from typing import List, Dict

def generate_pruning_plans(
    stability: Dict[str, float],
    n_layers: int,
    target_sparsities: List[float] = [0.30, 0.50, 0.70]
) -> List[Dict]:
    """
    Generate pruning plans by removing least important layers.
    
    For each target sparsity, create multiple plans:
    - Plan A: Remove lowest-scoring layers
    - Plan B: Remove lowest-scoring + some middle layers
    - Plan C: Remove distributed across layer ranges
    """
    
    ranked_layers = rank_layers_by_importance(stability)
    plans = []
    
    for sparsity in target_sparsities:
        n_to_remove = int(n_layers * sparsity)
        
        # Plan A: Bottom-N layers
        plan_a = ranked_layers[:n_to_remove]
        plans.append({
            "id": f"plan_sparsity_{sparsity:.0%}_bottomN",
            "remove_layers": plan_a,
            "sparsity": sparsity,
            "strategy": "Remove lowest-importance layers"
        })
        
        # Plan B: Distributed removal
        if n_to_remove > 1:
            stride = max(1, n_layers // n_to_remove)
            plan_b = [ranked_layers[i * stride] for i in range(n_to_remove)]
            plans.append({
                "id": f"plan_sparsity_{sparsity:.0%}_distributed",
                "remove_layers": plan_b,
                "sparsity": sparsity,
                "strategy": "Distributed removal"
            })
    
    return plans

# Example
stability = load_phase5_stability("gpt2")
plans = generate_pruning_plans(stability, n_layers=12)

for plan in plans:
    print(f"{plan['id']}: Remove {plan['remove_layers']}")
    
# Save for next step
save_json("experiments/phase10/gpt2_pruning_plans.json", plans)
```

### Step 1.4: Create Pruned Models

```python
"""step_1_4_create_pruned_models.py - Generate pruned model variants"""

from transformer_lens import HookedTransformer
import torch

def create_pruned_model(
    model_name: str,
    remove_layer_indices: List[int],
    device: str = "cuda"
):
    """
    Create a pruned model by removing specified layers.
    
    WARNING: This creates a modified model, not compatible with standard checkpoints.
    For production, would need to save/reload properly.
    """
    
    model = HookedTransformer.from_pretrained(model_name, device=device)
    original_n_layers = model.cfg.n_layers
    
    # Create mapping: old layer idx -> new layer idx
    layer_mapping = {}
    new_idx = 0
    for old_idx in range(original_n_layers):
        if old_idx not in remove_layer_indices:
            layer_mapping[old_idx] = new_idx
            new_idx += 1
    
    # Update model config
    model.cfg.n_layers = len(layer_mapping)
    
    # Remap blocks
    new_blocks = torch.nn.ModuleList()
    for old_idx in range(original_n_layers):
        if old_idx not in remove_layer_indices:
            new_blocks.append(model.blocks[old_idx])
    
    model.blocks = new_blocks
    
    return model, layer_mapping

# Example: Create 4-layer GPT-2 (from 12)
model, mapping = create_pruned_model("gpt2", remove_layer_indices=[1, 2, 5, 11])
print(f"Reduced from 12 to {model.cfg.n_layers} layers")
print(f"Layer mapping: {mapping}")
```

### Step 1.5: Validation - Compute Perplexity

```python
"""step_1_5_validate_tickets.py - Check if pruned models are winning tickets"""

import torch
import torch.nn.functional as F
from typing import Tuple

def compute_baseline_ppl(model_name: str, eval_texts: List[str]) -> float:
    """Compute baseline PPL for original model."""
    model = HookedTransformer.from_pretrained(model_name, device="cuda")
    model.eval()
    
    total_loss = 0.0
    total_tokens = 0
    
    for text in eval_texts:
        tokens = tokenizer.encode(text, return_tensors="pt").to("cuda")
        
        with torch.no_grad():
            logits = model(tokens)
        
        # Shift for LM task
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = tokens[..., 1:].contiguous()
        
        loss = F.cross_entropy(
            shift_logits.view(-1, shift_logits.size(-1)),
            shift_labels.view(-1)
        )
        
        total_loss += loss.item() * (tokens.shape[1] - 1)
        total_tokens += tokens.shape[1] - 1
    
    ppl = torch.exp(torch.tensor(total_loss / total_tokens)).item()
    return ppl

def validate_ticket(
    pruned_model,
    eval_texts: List[str],
    baseline_ppl: float,
    win_threshold: float = 0.01
) -> Dict:
    """
    Test if pruned model is a winning ticket.
    
    Win condition: PPL within 1% of baseline.
    """
    
    pruned_model.eval()
    total_loss = 0.0
    total_tokens = 0
    
    for text in eval_texts:
        tokens = tokenizer.encode(text, return_tensors="pt").to("cuda")
        
        with torch.no_grad():
            logits = pruned_model(tokens)
        
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = tokens[..., 1:].contiguous()
        
        loss = F.cross_entropy(
            shift_logits.view(-1, shift_logits.size(-1)),
            shift_labels.view(-1)
        )
        
        total_loss += loss.item() * (tokens.shape[1] - 1)
        total_tokens += tokens.shape[1] - 1
    
    ppl = torch.exp(torch.tensor(total_loss / total_tokens)).item()
    ppl_delta = (ppl - baseline_ppl) / baseline_ppl
    is_winner = ppl_delta <= win_threshold
    
    return {
        "ppl": ppl,
        "baseline_ppl": baseline_ppl,
        "ppl_delta": ppl_delta,
        "ppl_delta_pct": ppl_delta * 100,
        "is_winner": is_winner,
        "win_status": "WINNING TICKET" if is_winner else "FAILED"
    }

# Main workflow
def run_stage1():
    # Load baseline
    eval_texts = load_json("data/wikitext2_500_samples.json")
    baseline_ppl = compute_baseline_ppl("gpt2", eval_texts)
    
    # Load plans
    plans = load_json("experiments/phase10/gpt2_pruning_plans.json")
    
    # Test each plan
    results = []
    for plan in plans:
        print(f"Testing {plan['id']}...")
        
        pruned_model, _ = create_pruned_model("gpt2", plan['remove_layers'])
        validation = validate_ticket(pruned_model, eval_texts, baseline_ppl)
        
        result = {
            **plan,
            **validation
        }
        results.append(result)
        
        status = "✓ WINNER" if validation['is_winner'] else "✗ FAILED"
        print(f"  {status}: PPL {validation['ppl']:.2f} ({validation['ppl_delta_pct']:+.2f}%)")
    
    # Save results
    save_json("experiments/phase10/gpt2_stage1_results.json", results)
    
    # Summary
    winners = [r for r in results if r['is_winner']]
    print(f"\nFound {len(winners)} winning tickets out of {len(results)} plans")
    
    return results

if __name__ == "__main__":
    run_stage1()
```

---

## Stage 2: Iterative Refinement

### Binary Search for Sparsity Limit

```python
"""step_2_binary_search_sparsity.py - Find absolute sparsest winning ticket"""

def binary_search_sparsity(
    model_name: str,
    eval_texts: List[str],
    baseline_ppl: float,
    initial_winner_sparsity: float = 0.30,
    max_sparsity: float = 0.90
):
    """
    Binary search for the sparsest sparsity that still produces a winning ticket.
    
    Algorithm:
    1. Start with known winner (e.g., 30%)
    2. Try to increase sparsity (e.g., 60%)
    3. If wins, go higher; if fails, go back
    4. Repeat until convergence
    """
    
    low = initial_winner_sparsity
    high = max_sparsity
    best_winner = None
    
    while high - low > 0.05:  # Stop when margin < 5%
        mid = (low + high) / 2
        
        # Generate pruning plan for mid-sparsity
        stability = load_phase5_stability(model_name)
        n_layers = get_model_n_layers(model_name)
        ranked = rank_layers_by_importance(stability)
        remove_n = int(n_layers * mid)
        remove_layers = ranked[:remove_n]
        
        # Test if it's a winner
        pruned_model, _ = create_pruned_model(model_name, remove_layers)
        validation = validate_ticket(pruned_model, eval_texts, baseline_ppl)
        
        print(f"Sparsity {mid:.0%}: PPL delta {validation['ppl_delta_pct']:+.2f}% -> {'PASS' if validation['is_winner'] else 'FAIL'}")
        
        if validation['is_winner']:
            # Can go higher
            best_winner = {
                'sparsity': mid,
                'layers': remove_layers,
                'validation': validation
            }
            low = mid
        else:
            # Can't go higher
            high = mid
    
    return best_winner

# Run binary search
best = binary_search_sparsity("gpt2", eval_texts, baseline_ppl)
print(f"✓ Best ticket: {best['sparsity']:.0%} sparsity")
```

---

## Stage 3: Cross-Model Pattern Analysis

```python
"""step_3_pattern_analysis.py - Analyze which layers matter across models"""

import json
from typing import Dict, List

def analyze_layer_importance_patterns(
    winners: Dict[str, Dict]
) -> Dict:
    """
    Find universal patterns:
    - Which layers consistently removed?
    - Which layers never removed?
    - Architecture-specific patterns?
    """
    
    all_models = list(winners.keys())
    all_layers_union = set()
    removed_by_model = {}
    
    # Collect all removed layers per model
    for model_name, winner in winners.items():
        removed = set(winner['remove_layers'])
        removed_by_model[model_name] = removed
        all_layers_union.update(removed)
    
    # Count frequency of removal
    removal_frequency = {}
    for layer in all_layers_union:
        count = sum(1 for r in removed_by_model.values() if layer in r)
        removal_frequency[layer] = count / len(all_models)
    
    # Categorize layers
    universal_layers = [l for l, f in removal_frequency.items() if f > 0.66]
    common_layers = [l for l, f in removal_frequency.items() if 0.33 <= f <= 0.66]
    rare_layers = [l for l, f in removal_frequency.items() if f < 0.33]
    
    return {
        "universal_layers": universal_layers,
        "common_layers": common_layers,
        "rare_layers": rare_layers,
        "removal_frequency": removal_frequency,
        "models_analyzed": all_models
    }

# Example
winners = {
    "gpt2": {...},
    "mistral": {...},
    "llama3": {...}
}

patterns = analyze_layer_importance_patterns(winners)
print(f"Universal layers: {patterns['universal_layers']}")
```

---

## Stage 4: Deployment Metrics

```python
"""step_4_deployment_metrics.py - Measure real-world efficiency"""

import torch
import time

def measure_latency(model, num_tokens: int = 100, num_trials: int = 10) -> float:
    """Measure time to generate tokens."""
    times = []
    
    for _ in range(num_trials):
        input_ids = torch.randint(0, 50257, (1, 1))
        
        start = time.time()
        with torch.no_grad():
            for _ in range(num_tokens):
                logits = model(input_ids)
                next_token = torch.argmax(logits[0, -1, :])
                input_ids = torch.cat([input_ids, next_token.unsqueeze(0).unsqueeze(0)], dim=1)
        
        times.append(time.time() - start)
    
    return sum(times) / len(times) / num_tokens  # Per-token latency

def measure_memory(model) -> int:
    """Measure peak GPU memory usage."""
    torch.cuda.reset_peak_memory_stats()
    
    # Dummy forward pass
    input_ids = torch.randint(0, 50257, (1, 128))
    with torch.no_grad():
        _ = model(input_ids)
    
    peak_memory = torch.cuda.max_memory_allocated()
    return peak_memory / (1024 ** 3)  # GB

def compute_deployment_score(
    baseline_metrics: Dict,
    ticket_metrics: Dict
) -> Dict:
    """Compute overall efficiency gain."""
    
    params_reduction = 1 - (ticket_metrics['params'] / baseline_metrics['params'])
    memory_reduction = 1 - (ticket_metrics['memory_gb'] / baseline_metrics['memory_gb'])
    latency_improvement = 1 - (ticket_metrics['latency_ms'] / baseline_metrics['latency_ms'])
    
    # Quality preservation
    ppl_loss = (ticket_metrics['ppl'] - baseline_metrics['ppl']) / baseline_metrics['ppl']
    quality_preservation = max(0, 1 - ppl_loss)
    
    # Overall score: average efficiency gains, penalized by quality loss
    efficiency_score = (
        (params_reduction + memory_reduction + latency_improvement) / 3
    ) * quality_preservation
    
    return {
        "params_reduction": params_reduction,
        "memory_reduction": memory_reduction,
        "latency_improvement": latency_improvement,
        "quality_preservation": quality_preservation,
        "overall_efficiency_score": efficiency_score
    }
```

---

## Integration Checklist

- [ ] Step 1.1: Data prepared
- [ ] Step 1.2: Stability scores loaded
- [ ] Step 1.3: Pruning plans generated
- [ ] Step 1.4: Pruned models created
- [ ] Step 1.5: Validation completed
- [ ] Stage 2: Binary search executed
- [ ] Stage 3: Patterns analyzed
- [ ] Stage 4: Metrics computed
- [ ] Results saved & documented

---

## Next Steps

1. Implement Stage 1 completely
2. Run on GPT-2 first (fast, known baseline)
3. Validate patterns, then scale to Mistral/Llama
4. Generate deployment guide
5. Prepare paper/documentation

---

*Implementation Guide for Phase 10*  
*TIM-MGDT Project*
