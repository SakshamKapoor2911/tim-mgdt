# Phase 8: Mistral-7B Scaling Validation

**Status**: ⏸️ BLOCKED (Awaiting GPU Compute APIs)  
**Planned Date**: TBD (after GPU setup)  
**Model**: Mistral-7B (7B parameters, larger architecture)  
**Dataset**: WikiText-2 (500 samples, same as Phase 6)  
**Goal**: Verify if 0.98x scaling principle scales from GPT-2 to 7B-class models

---

## Objective

Test whether the 0.98x Layer 10 scaling breakthrough discovered on GPT-2 **transfers to larger, modern language models** like Mistral-7B.

**Critical Question**: 
> "Does the layer importance distribution and elasticity pattern hold at 60x larger scale?"

---

## Motivation

| Aspect | GPT-2 | Mistral-7B | Tension |
|--------|-------|-----------|---------|
| Parameters | 117M | 7B | 60x larger |
| Layers | 12 | 32 | Different depth |
| Attention Heads | 12 | 32 | More complex |
| Hidden Dim | 768 | 4096 | Higher capacity |

If scaling works on Mistral-7B, it proves the technique is **architecture-agnostic** and ready for production deployment.

---

## Experimental Design

### Baseline Phase

1. Load Mistral-7B on GPU (requires GPU APIs)
2. Compute baseline PPL on 500 WikiText-2 samples
3. Record token count, total loss

### Scale Factor Testing (Same as Phase 6)

Test identical scale factors:
- 0.90x, 0.92x, 0.95x, 0.98x, 1.00x

For **Layer 16** (middle layer, analogous to Layer 10 in depth ratio):
- Mistral-7B has 32 layers → layer 16 is proportionally similar

### Comparison Metrics

| Metric | GPT-2 Result | Mistral-7B Result | Comparison |
|--------|--------------|-------------------|-----------|
| Baseline PPL | 51.43 | TBD | Scale? |
| 0.98x Scale PPL | 51.37 | TBD | Consistent? |
| PPL Delta (%) | -0.11% | TBD | Generalizes? |

---

## Key Questions

1. **Portability**: Does 0.98x work on larger models, or is it tuned to GPT-2?
2. **Scaling Law**: Does sensitivity scale with model size? (Inverse relationship expected)
3. **Depth Effect**: Does layer position matter more on 32-layer models?
4. **Quantization Foundation**: Can we build safe quantization maps with Mistral-7B?

---

## Deployment Requirements

### GPU Setup Needed

- **Framework**: PyTorch + HuggingFace Transformers
- **VRAM**: ~16GB (for 7B model FP16 + inference)
- **Tools**: TransformerLens (may need integration)
- **APIs**: Azure GPU compute or similar (user to provision)

### Code Adaptation

```python
# Phase 8 structure (similar to Phase 6, different model)
model = AutoModelForCausalLM.from_pretrained("mistralai/Mistral-7B")
# Find layer 16 (mid-depth, analogous to layer 10 in GPT-2)
for name, param in model.named_parameters():
    if ".16." in name:  # Layer 16
        param.data = param.data * 0.98
```

---

## Success Criteria

✅ **Pass**: PPL delta at ±2% on Mistral-7B  
⚠️ **Acceptable**: PPL delta at ±5% (different architecture effects)  
❌ **Fail**: PPL delta >±10% (technique doesn't generalize to large models)

---

## Expected Outcome

### Likely: 0.98x Scales Well

- Sensitivity distributions are architecture-invariant
- Layer elasticity is a fundamental property
- Ready to apply to other 7B-class models (LLaMA-2, etc.)

### Alternative: Requires Retuning

- 0.93x or 0.95x better for Mistral-7B
- Layer position matters more at scale
- Need model-specific calibration

---

## Files

- **Code**: [code/](code/) (to be created post-GPU setup)
- **Experiments**: [experiments/](experiments/)

---

## Blocking Issue

🔴 **Awaiting GPU Compute APIs**  
Current setup is CPU-only. Mistral-7B inference requires GPU. User to:
1. Provision Azure GPU compute or similar
2. Set up CUDA environment
3. Provide GPU API credentials

Once available, run:
```bash
python code/mistral_validation.py --num-samples 500 --model mistralai/Mistral-7B
```

---

## Timeline

- **Phase 6**: Complete ✓
- **Phase 7**: Alternative corpus testing (parallel with Phase 8 blocking)
- **Phase 8**: GPU setup + Mistral-7B scaling (this phase)
- **Phase 9**: Downstream tasks

---

## References

- Phase 6: GPT-2 validation (establishes baseline 0.98x discovery)
- Phase 7: Alternative corpora (validates generalization to datasets)
- Interventions: All downstream (use Mistral-7B for scalable compression)
