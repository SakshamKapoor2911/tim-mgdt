# Phase 6: Layer Elasticity vs. Destruction

**Purpose**: This document captures the empirical discovery from Phase 6 that fundamentally changes how we approach "critical" layer compression.

## The Core Insight: Critical Layers are Elastic
Phase 4 identified Layer 10 in GPT-2 as the 2nd most critical layer in the network. Traditional pruning methodology assumes that "critical" layers are glass (i.e., highly fragile) and should never be touched.

**The Hard-Pruning Failure (Phase 5.1)**:
When we attempted hard-pruning (complete ablation) of Layer 10, the perplexity exploded by **+108%**. This initially seemed to confirm the fragility hypothesis.

**The Elasticity Discovery (Phase 6)**:
We hypothesized that the layer wasn't broken, but rather over-weighted. We shifted from destructive pruning to "Soft-Scaling" (multiplying the layer's weights by 0.98x).
On a robust 500-sample WikiText-2 validation set, scaling Layer 10 by 0.98x actually **improved** baseline perplexity by **0.11%** (from 51.43 to 51.37). 

## Architectural Impact
This proves that layers exhibiting high causal sensitivity are not untouchable. Their sensitivity implies *leverage*, not just fragility. By applying geometric interventions (like quantization or soft-scaling) rather than destructive topological interventions (like unstructured pruning), we can compress critical layers while utilizing their leverage as an implicit regularizer. 

**Raw Data Reference**: `results/phase6_validation_results.json`
