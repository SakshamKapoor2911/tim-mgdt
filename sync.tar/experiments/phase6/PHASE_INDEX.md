# Phase 6 Index: Integration Validation

## Canonical Runs
- **Model:** GPT-2
- **Dataset:** WikiText-2
- **Run ID:** [baseline_legacy](gpt2/wikitext2/baseline_legacy/)
- **Summary:** End-to-end pipeline validation confirmed high correlation between proxies and ground truth across multiple pruning scenarios.

## Key Artifacts
- [Validation Report](gpt2/wikitext2/baseline_legacy/phase6_validation_report.md)
- [Validation Results](gpt2/wikitext2/baseline_legacy/phase6_validation_results.json)
