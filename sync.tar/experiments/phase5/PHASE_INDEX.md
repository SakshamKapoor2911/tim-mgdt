# Phase 5 Index: Advanced Proxies & Compression

## Canonical Runs
- **Model:** GPT-2
- **Dataset:** WikiText-2
- **Run ID:** [baseline_legacy](gpt2/wikitext2/baseline_legacy/)
- **Summary:** Successfully demonstrated that Advanced Proxies (Head Jacobian, Circuit Analyzer) can guide pruning with minimal performance loss.

## Key Artifacts
- [Final Report](gpt2/wikitext2/baseline_legacy/phase5_final_report.md)
- [Strategy Matrix](gpt2/wikitext2/baseline_legacy/phase5_strategy_matrix.md)
- [Integrated Results](gpt2/wikitext2/baseline_legacy/phase5_integrated_results.json)
