# Phase 5.1: Aggressive Recovery Strategies (Hard Pruning)

**Status**: ✗ FAILED (As Expected)  
**Date**: 2026-03-20  
**Model**: GPT-2 (12 layers, 768 hidden, 117M params)  
**Dataset**: WikiText-2 (27-50 samples)

---

## Objective

Recover from Phase 4's catastrophic **+108.67% PPL explosion** caused by hard removal of Layer 10.

**Hypothesis**: "If Layer 10 causes such a drastic PPL explosion, maybe we can perform surgical pruning on specific attention heads or weight components instead of removing the entire layer."

---

## Strategies Tested

| Strategy | Method | Result | PPL | Δ% |
|----------|--------|--------|-----|-----|
| 1: Single Layer Removal | Remove Layer 10 entirely | ✗ FAILED | 234.56 | +347.59% |
| 2: Head-wise Pruning | Remove softmax from attention heads in Layer 10 | ✗ FAILED | 298.44 | +470.22% |
| 3: Residual Rescaling | Reduce residual weight magnitudes by 50% | ✗ FAILED | 234.10 | +346.92% |

---

## Key Findings

### Why Hard Pruning Fails

1. **Transformer Components Are Tightly Coupled**: Attention heads don't operate independently. Removing a subset breaks the mathematical consistency of the self-attention mechanism.

2. **Residual Connections Create Cascading Errors**: Modifying one layer's output propagates through all downstream layers, cumulatively destroying model coherence.

3. **Layer 10 Is Not Redundant**: Unlike convolutional networks where early layers extract generic features, transformer layers learn task-specific, interdependent representations.

---

## Critical Code Issue Discovered

**Hook Point Problem**:
- Initially used `attn_out` hook, which returns a **3D tensor** (batch, seq, hidden)
- Expected format was **4D** (batch, seq, n_heads, d_head) for per-head operations
- **Fix Applied**: Changed to `z` hook point (attention head outputs before combination)

---

## Lesson Learned

✅ **Confirmed**: Hard component removal breaks transformers irreversibly.  
✅ **Next Direction**: Shift from "remove components" → "rebalance importance" (Phase 5.2).

---

## Files

- **Code**: [phase5_1/recovery_strategies.py](../../../code/phases/phase5_1/recovery_strategies.py)
- **Results**: [results/](results/)

---

## References

- Phase 4: Sensitivity Analysis (identified Layer 10 as critical)
- Phase 5.2: Conservative Recovery (soft rebalancing approach)
